package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

public interface WrappedDrawable {
  Drawable getWrappedDrawable();
  
  void setWrappedDrawable(Drawable paramDrawable);
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/v4/graphics/drawable/WrappedDrawable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */