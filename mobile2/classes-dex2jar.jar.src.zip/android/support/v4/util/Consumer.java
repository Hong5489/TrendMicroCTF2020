package android.support.v4.util;

public interface Consumer<T> {
  void accept(T paramT);
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/v4/util/Consumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */