package android.support.design.transformation;

import android.content.Context;
import android.support.design.circularreveal.cardview.CircularRevealCardView;
import android.util.AttributeSet;

public class TransformationChildCard extends CircularRevealCardView {
  public TransformationChildCard(Context paramContext) {
    this(paramContext, null);
  }
  
  public TransformationChildCard(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/design/transformation/TransformationChildCard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */