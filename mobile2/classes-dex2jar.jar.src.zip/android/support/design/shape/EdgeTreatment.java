package android.support.design.shape;

public class EdgeTreatment {
  public void getEdgePath(float paramFloat1, float paramFloat2, ShapePath paramShapePath) {
    paramShapePath.lineTo(paramFloat1, 0.0F);
  }
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/design/shape/EdgeTreatment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */