package android.support.design.shape;

public class CornerTreatment {
  public void getCornerPath(float paramFloat1, float paramFloat2, ShapePath paramShapePath) {}
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/design/shape/CornerTreatment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */