package android.support.design.snackbar;

public interface ContentViewCallback {
  void animateContentIn(int paramInt1, int paramInt2);
  
  void animateContentOut(int paramInt1, int paramInt2);
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/design/snackbar/ContentViewCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */