package android.support.design.animation;

public class Positioning {
  public final int gravity;
  
  public final float xAdjustment;
  
  public final float yAdjustment;
  
  public Positioning(int paramInt, float paramFloat1, float paramFloat2) {
    this.gravity = paramInt;
    this.xAdjustment = paramFloat1;
    this.yAdjustment = paramFloat2;
  }
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/design/animation/Positioning.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */