package android.support.design.expandable;

public interface ExpandableTransformationWidget extends ExpandableWidget {
  int getExpandedComponentIdHint();
  
  void setExpandedComponentIdHint(int paramInt);
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/design/expandable/ExpandableTransformationWidget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */