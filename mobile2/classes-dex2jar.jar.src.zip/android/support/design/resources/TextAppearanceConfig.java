package android.support.design.resources;

public class TextAppearanceConfig {
  private static boolean shouldLoadFontSynchronously;
  
  public static void setShouldLoadFontSynchronously(boolean paramBoolean) {
    shouldLoadFontSynchronously = paramBoolean;
  }
  
  public static boolean shouldLoadFontSynchronously() {
    return shouldLoadFontSynchronously;
  }
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/design/resources/TextAppearanceConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */