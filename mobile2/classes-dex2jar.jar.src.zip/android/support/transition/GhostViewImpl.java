package android.support.transition;

import android.view.View;
import android.view.ViewGroup;

interface GhostViewImpl {
  void reserveEndViewTransition(ViewGroup paramViewGroup, View paramView);
  
  void setVisibility(int paramInt);
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/transition/GhostViewImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */