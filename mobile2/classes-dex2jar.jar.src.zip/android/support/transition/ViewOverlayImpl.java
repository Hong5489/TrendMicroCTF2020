package android.support.transition;

import android.graphics.drawable.Drawable;

interface ViewOverlayImpl {
  void add(Drawable paramDrawable);
  
  void clear();
  
  void remove(Drawable paramDrawable);
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/transition/ViewOverlayImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */