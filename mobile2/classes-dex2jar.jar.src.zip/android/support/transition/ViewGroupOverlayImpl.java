package android.support.transition;

import android.view.View;

interface ViewGroupOverlayImpl extends ViewOverlayImpl {
  void add(View paramView);
  
  void remove(View paramView);
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/support/transition/ViewGroupOverlayImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */