package android.arch.lifecycle;

public class MutableLiveData<T> extends LiveData<T> {
  public void postValue(T paramT) {
    super.postValue(paramT);
  }
  
  public void setValue(T paramT) {
    super.setValue(paramT);
  }
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/arch/lifecycle/MutableLiveData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */