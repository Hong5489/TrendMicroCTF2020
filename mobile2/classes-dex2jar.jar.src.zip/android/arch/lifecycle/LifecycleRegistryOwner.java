package android.arch.lifecycle;

@Deprecated
public interface LifecycleRegistryOwner extends LifecycleOwner {
  LifecycleRegistry getLifecycle();
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/arch/lifecycle/LifecycleRegistryOwner.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */