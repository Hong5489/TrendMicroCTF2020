package android.arch.lifecycle;

public interface GeneratedAdapter {
  void callMethods(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent, boolean paramBoolean, MethodCallsLogger paramMethodCallsLogger);
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes-dex2jar.jar!/android/arch/lifecycle/GeneratedAdapter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */