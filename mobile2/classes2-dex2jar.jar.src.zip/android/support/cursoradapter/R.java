package android.support.cursoradapter;

public final class R {}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes2-dex2jar.jar!/android/support/cursoradapter/R.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */