package android.support.coreui;

public final class R {
  public static final class attr {
    public static final int alpha = 2130903079;
    
    public static final int coordinatorLayoutStyle = 2130903204;
    
    public static final int font = 2130903255;
    
    public static final int fontProviderAuthority = 2130903257;
    
    public static final int fontProviderCerts = 2130903258;
    
    public static final int fontProviderFetchStrategy = 2130903259;
    
    public static final int fontProviderFetchTimeout = 2130903260;
    
    public static final int fontProviderPackage = 2130903261;
    
    public static final int fontProviderQuery = 2130903262;
    
    public static final int fontStyle = 2130903263;
    
    public static final int fontVariationSettings = 2130903264;
    
    public static final int fontWeight = 2130903265;
    
    public static final int keylines = 2130903309;
    
    public static final int layout_anchor = 2130903314;
    
    public static final int layout_anchorGravity = 2130903315;
    
    public static final int layout_behavior = 2130903316;
    
    public static final int layout_dodgeInsetEdges = 2130903360;
    
    public static final int layout_insetEdge = 2130903369;
    
    public static final int layout_keyline = 2130903370;
    
    public static final int statusBarBackground = 2130903462;
    
    public static final int ttcIndex = 2130903560;
  }
  
  public static final class color {
    public static final int notification_action_color_filter = 2131034220;
    
    public static final int notification_icon_bg_color = 2131034221;
    
    public static final int ripple_material_light = 2131034231;
    
    public static final int secondary_text_default_material_light = 2131034233;
  }
  
  public static final class dimen {
    public static final int compat_button_inset_horizontal_material = 2131099726;
    
    public static final int compat_button_inset_vertical_material = 2131099727;
    
    public static final int compat_button_padding_horizontal_material = 2131099728;
    
    public static final int compat_button_padding_vertical_material = 2131099729;
    
    public static final int compat_control_corner_material = 2131099730;
    
    public static final int compat_notification_large_icon_max_height = 2131099731;
    
    public static final int compat_notification_large_icon_max_width = 2131099732;
    
    public static final int notification_action_icon_size = 2131099841;
    
    public static final int notification_action_text_size = 2131099842;
    
    public static final int notification_big_circle_margin = 2131099843;
    
    public static final int notification_content_margin_start = 2131099844;
    
    public static final int notification_large_icon_height = 2131099845;
    
    public static final int notification_large_icon_width = 2131099846;
    
    public static final int notification_main_column_padding_top = 2131099847;
    
    public static final int notification_media_narrow_margin = 2131099848;
    
    public static final int notification_right_icon_size = 2131099849;
    
    public static final int notification_right_side_padding_top = 2131099850;
    
    public static final int notification_small_icon_background_padding = 2131099851;
    
    public static final int notification_small_icon_size_as_large = 2131099852;
    
    public static final int notification_subtext_size = 2131099853;
    
    public static final int notification_top_pad = 2131099854;
    
    public static final int notification_top_pad_large_text = 2131099855;
  }
  
  public static final class drawable {
    public static final int notification_action_background = 2131165298;
    
    public static final int notification_bg = 2131165299;
    
    public static final int notification_bg_low = 2131165300;
    
    public static final int notification_bg_low_normal = 2131165301;
    
    public static final int notification_bg_low_pressed = 2131165302;
    
    public static final int notification_bg_normal = 2131165303;
    
    public static final int notification_bg_normal_pressed = 2131165304;
    
    public static final int notification_icon_background = 2131165305;
    
    public static final int notification_template_icon_bg = 2131165306;
    
    public static final int notification_template_icon_low_bg = 2131165307;
    
    public static final int notification_tile_bg = 2131165308;
    
    public static final int notify_panel_notification_icon_bg = 2131165309;
  }
  
  public static final class id {
    public static final int action_container = 2131230733;
    
    public static final int action_divider = 2131230735;
    
    public static final int action_image = 2131230736;
    
    public static final int action_text = 2131230742;
    
    public static final int actions = 2131230743;
    
    public static final int async = 2131230749;
    
    public static final int blocking = 2131230753;
    
    public static final int bottom = 2131230754;
    
    public static final int chronometer = 2131230761;
    
    public static final int end = 2131230783;
    
    public static final int forever = 2131230795;
    
    public static final int icon = 2131230804;
    
    public static final int icon_group = 2131230805;
    
    public static final int info = 2131230808;
    
    public static final int italic = 2131230810;
    
    public static final int left = 2131230823;
    
    public static final int line1 = 2131230824;
    
    public static final int line3 = 2131230825;
    
    public static final int none = 2131230838;
    
    public static final int normal = 2131230839;
    
    public static final int notification_background = 2131230840;
    
    public static final int notification_main_column = 2131230841;
    
    public static final int notification_main_column_container = 2131230842;
    
    public static final int right = 2131230854;
    
    public static final int right_icon = 2131230855;
    
    public static final int right_side = 2131230856;
    
    public static final int start = 2131230895;
    
    public static final int tag_transition_group = 2131230900;
    
    public static final int tag_unhandled_key_event_manager = 2131230901;
    
    public static final int tag_unhandled_key_listeners = 2131230902;
    
    public static final int text = 2131230903;
    
    public static final int text2 = 2131230904;
    
    public static final int time = 2131230920;
    
    public static final int title = 2131230921;
    
    public static final int top = 2131230926;
  }
  
  public static final class integer {
    public static final int status_bar_notification_info_maxnum = 2131296270;
  }
  
  public static final class layout {
    public static final int notification_action = 2131427386;
    
    public static final int notification_action_tombstone = 2131427387;
    
    public static final int notification_template_custom_big = 2131427388;
    
    public static final int notification_template_icon_group = 2131427389;
    
    public static final int notification_template_part_chronometer = 2131427390;
    
    public static final int notification_template_part_time = 2131427391;
  }
  
  public static final class string {
    public static final int status_bar_notification_info_overflow = 2131558455;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131624216;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131624217;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131624218;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131624219;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131624220;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131624386;
    
    public static final int Widget_Compat_NotificationActionText = 2131624387;
    
    public static final int Widget_Support_CoordinatorLayout = 2131624434;
  }
  
  public static final class styleable {
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130903079 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] CoordinatorLayout = new int[] { 2130903309, 2130903462 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130903314, 2130903315, 2130903316, 2130903360, 2130903369, 2130903370 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] FontFamily = new int[] { 2130903257, 2130903258, 2130903259, 2130903260, 2130903261, 2130903262 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903255, 2130903263, 2130903264, 2130903265, 2130903560 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
  }
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes2-dex2jar.jar!/android/support/coreui/R.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */