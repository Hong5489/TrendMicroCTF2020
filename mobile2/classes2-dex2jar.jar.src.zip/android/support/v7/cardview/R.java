package android.support.v7.cardview;

public final class R {
  public static final class attr {
    public static final int cardBackgroundColor = 2130903130;
    
    public static final int cardCornerRadius = 2130903131;
    
    public static final int cardElevation = 2130903132;
    
    public static final int cardMaxElevation = 2130903133;
    
    public static final int cardPreventCornerOverlap = 2130903134;
    
    public static final int cardUseCompatPadding = 2130903135;
    
    public static final int cardViewStyle = 2130903136;
    
    public static final int contentPadding = 2130903197;
    
    public static final int contentPaddingBottom = 2130903198;
    
    public static final int contentPaddingLeft = 2130903199;
    
    public static final int contentPaddingRight = 2130903200;
    
    public static final int contentPaddingTop = 2130903201;
  }
  
  public static final class color {
    public static final int cardview_dark_background = 2131034150;
    
    public static final int cardview_light_background = 2131034151;
    
    public static final int cardview_shadow_end_color = 2131034152;
    
    public static final int cardview_shadow_start_color = 2131034153;
  }
  
  public static final class dimen {
    public static final int cardview_compat_inset_shadow = 2131099723;
    
    public static final int cardview_default_elevation = 2131099724;
    
    public static final int cardview_default_radius = 2131099725;
  }
  
  public static final class style {
    public static final int Base_CardView = 2131623951;
    
    public static final int CardView = 2131624134;
    
    public static final int CardView_Dark = 2131624135;
    
    public static final int CardView_Light = 2131624136;
  }
  
  public static final class styleable {
    public static final int[] CardView = new int[] { 
        16843071, 16843072, 2130903130, 2130903131, 2130903132, 2130903133, 2130903134, 2130903135, 2130903197, 2130903198, 
        2130903199, 2130903200, 2130903201 };
    
    public static final int CardView_android_minHeight = 1;
    
    public static final int CardView_android_minWidth = 0;
    
    public static final int CardView_cardBackgroundColor = 2;
    
    public static final int CardView_cardCornerRadius = 3;
    
    public static final int CardView_cardElevation = 4;
    
    public static final int CardView_cardMaxElevation = 5;
    
    public static final int CardView_cardPreventCornerOverlap = 6;
    
    public static final int CardView_cardUseCompatPadding = 7;
    
    public static final int CardView_contentPadding = 8;
    
    public static final int CardView_contentPaddingBottom = 9;
    
    public static final int CardView_contentPaddingLeft = 10;
    
    public static final int CardView_contentPaddingRight = 11;
    
    public static final int CardView_contentPaddingTop = 12;
  }
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes2-dex2jar.jar!/android/support/v7/cardview/R.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */