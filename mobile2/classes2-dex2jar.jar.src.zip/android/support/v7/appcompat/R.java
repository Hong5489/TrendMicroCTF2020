package android.support.v7.appcompat;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130771968;
    
    public static final int abc_fade_out = 2130771969;
    
    public static final int abc_grow_fade_in_from_bottom = 2130771970;
    
    public static final int abc_popup_enter = 2130771971;
    
    public static final int abc_popup_exit = 2130771972;
    
    public static final int abc_shrink_fade_out_from_bottom = 2130771973;
    
    public static final int abc_slide_in_bottom = 2130771974;
    
    public static final int abc_slide_in_top = 2130771975;
    
    public static final int abc_slide_out_bottom = 2130771976;
    
    public static final int abc_slide_out_top = 2130771977;
    
    public static final int abc_tooltip_enter = 2130771978;
    
    public static final int abc_tooltip_exit = 2130771979;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130903040;
    
    public static final int actionBarItemBackground = 2130903041;
    
    public static final int actionBarPopupTheme = 2130903042;
    
    public static final int actionBarSize = 2130903043;
    
    public static final int actionBarSplitStyle = 2130903044;
    
    public static final int actionBarStyle = 2130903045;
    
    public static final int actionBarTabBarStyle = 2130903046;
    
    public static final int actionBarTabStyle = 2130903047;
    
    public static final int actionBarTabTextStyle = 2130903048;
    
    public static final int actionBarTheme = 2130903049;
    
    public static final int actionBarWidgetTheme = 2130903050;
    
    public static final int actionButtonStyle = 2130903051;
    
    public static final int actionDropDownStyle = 2130903052;
    
    public static final int actionLayout = 2130903053;
    
    public static final int actionMenuTextAppearance = 2130903054;
    
    public static final int actionMenuTextColor = 2130903055;
    
    public static final int actionModeBackground = 2130903056;
    
    public static final int actionModeCloseButtonStyle = 2130903057;
    
    public static final int actionModeCloseDrawable = 2130903058;
    
    public static final int actionModeCopyDrawable = 2130903059;
    
    public static final int actionModeCutDrawable = 2130903060;
    
    public static final int actionModeFindDrawable = 2130903061;
    
    public static final int actionModePasteDrawable = 2130903062;
    
    public static final int actionModePopupWindowStyle = 2130903063;
    
    public static final int actionModeSelectAllDrawable = 2130903064;
    
    public static final int actionModeShareDrawable = 2130903065;
    
    public static final int actionModeSplitBackground = 2130903066;
    
    public static final int actionModeStyle = 2130903067;
    
    public static final int actionModeWebSearchDrawable = 2130903068;
    
    public static final int actionOverflowButtonStyle = 2130903069;
    
    public static final int actionOverflowMenuStyle = 2130903070;
    
    public static final int actionProviderClass = 2130903071;
    
    public static final int actionViewClass = 2130903072;
    
    public static final int activityChooserViewStyle = 2130903073;
    
    public static final int alertDialogButtonGroupStyle = 2130903074;
    
    public static final int alertDialogCenterButtons = 2130903075;
    
    public static final int alertDialogStyle = 2130903076;
    
    public static final int alertDialogTheme = 2130903077;
    
    public static final int allowStacking = 2130903078;
    
    public static final int alpha = 2130903079;
    
    public static final int alphabeticModifiers = 2130903080;
    
    public static final int arrowHeadLength = 2130903081;
    
    public static final int arrowShaftLength = 2130903082;
    
    public static final int autoCompleteTextViewStyle = 2130903083;
    
    public static final int autoSizeMaxTextSize = 2130903084;
    
    public static final int autoSizeMinTextSize = 2130903085;
    
    public static final int autoSizePresetSizes = 2130903086;
    
    public static final int autoSizeStepGranularity = 2130903087;
    
    public static final int autoSizeTextType = 2130903088;
    
    public static final int background = 2130903089;
    
    public static final int backgroundSplit = 2130903090;
    
    public static final int backgroundStacked = 2130903091;
    
    public static final int backgroundTint = 2130903092;
    
    public static final int backgroundTintMode = 2130903093;
    
    public static final int barLength = 2130903094;
    
    public static final int borderlessButtonStyle = 2130903104;
    
    public static final int buttonBarButtonStyle = 2130903118;
    
    public static final int buttonBarNegativeButtonStyle = 2130903119;
    
    public static final int buttonBarNeutralButtonStyle = 2130903120;
    
    public static final int buttonBarPositiveButtonStyle = 2130903121;
    
    public static final int buttonBarStyle = 2130903122;
    
    public static final int buttonGravity = 2130903123;
    
    public static final int buttonIconDimen = 2130903124;
    
    public static final int buttonPanelSideLayout = 2130903125;
    
    public static final int buttonStyle = 2130903126;
    
    public static final int buttonStyleSmall = 2130903127;
    
    public static final int buttonTint = 2130903128;
    
    public static final int buttonTintMode = 2130903129;
    
    public static final int checkboxStyle = 2130903138;
    
    public static final int checkedTextViewStyle = 2130903143;
    
    public static final int closeIcon = 2130903162;
    
    public static final int closeItemLayout = 2130903169;
    
    public static final int collapseContentDescription = 2130903170;
    
    public static final int collapseIcon = 2130903171;
    
    public static final int color = 2130903174;
    
    public static final int colorAccent = 2130903175;
    
    public static final int colorBackgroundFloating = 2130903176;
    
    public static final int colorButtonNormal = 2130903177;
    
    public static final int colorControlActivated = 2130903178;
    
    public static final int colorControlHighlight = 2130903179;
    
    public static final int colorControlNormal = 2130903180;
    
    public static final int colorError = 2130903181;
    
    public static final int colorPrimary = 2130903182;
    
    public static final int colorPrimaryDark = 2130903183;
    
    public static final int colorSwitchThumbNormal = 2130903185;
    
    public static final int commitIcon = 2130903186;
    
    public static final int contentDescription = 2130903190;
    
    public static final int contentInsetEnd = 2130903191;
    
    public static final int contentInsetEndWithActions = 2130903192;
    
    public static final int contentInsetLeft = 2130903193;
    
    public static final int contentInsetRight = 2130903194;
    
    public static final int contentInsetStart = 2130903195;
    
    public static final int contentInsetStartWithNavigation = 2130903196;
    
    public static final int controlBackground = 2130903203;
    
    public static final int coordinatorLayoutStyle = 2130903204;
    
    public static final int customNavigationLayout = 2130903210;
    
    public static final int defaultQueryHint = 2130903211;
    
    public static final int dialogCornerRadius = 2130903212;
    
    public static final int dialogPreferredPadding = 2130903213;
    
    public static final int dialogTheme = 2130903214;
    
    public static final int displayOptions = 2130903215;
    
    public static final int divider = 2130903216;
    
    public static final int dividerHorizontal = 2130903217;
    
    public static final int dividerPadding = 2130903218;
    
    public static final int dividerVertical = 2130903219;
    
    public static final int drawableSize = 2130903220;
    
    public static final int drawerArrowStyle = 2130903221;
    
    public static final int dropDownListViewStyle = 2130903222;
    
    public static final int dropdownListPreferredItemHeight = 2130903223;
    
    public static final int editTextBackground = 2130903224;
    
    public static final int editTextColor = 2130903225;
    
    public static final int editTextStyle = 2130903226;
    
    public static final int elevation = 2130903227;
    
    public static final int expandActivityOverflowButtonDrawable = 2130903233;
    
    public static final int firstBaselineToTopHeight = 2130903253;
    
    public static final int font = 2130903255;
    
    public static final int fontFamily = 2130903256;
    
    public static final int fontProviderAuthority = 2130903257;
    
    public static final int fontProviderCerts = 2130903258;
    
    public static final int fontProviderFetchStrategy = 2130903259;
    
    public static final int fontProviderFetchTimeout = 2130903260;
    
    public static final int fontProviderPackage = 2130903261;
    
    public static final int fontProviderQuery = 2130903262;
    
    public static final int fontStyle = 2130903263;
    
    public static final int fontVariationSettings = 2130903264;
    
    public static final int fontWeight = 2130903265;
    
    public static final int gapBetweenBars = 2130903267;
    
    public static final int goIcon = 2130903268;
    
    public static final int height = 2130903270;
    
    public static final int hideOnContentScroll = 2130903275;
    
    public static final int homeAsUpIndicator = 2130903280;
    
    public static final int homeLayout = 2130903281;
    
    public static final int icon = 2130903283;
    
    public static final int iconTint = 2130903289;
    
    public static final int iconTintMode = 2130903290;
    
    public static final int iconifiedByDefault = 2130903291;
    
    public static final int imageButtonStyle = 2130903292;
    
    public static final int indeterminateProgressStyle = 2130903293;
    
    public static final int initialActivityCount = 2130903294;
    
    public static final int isLightTheme = 2130903296;
    
    public static final int itemPadding = 2130903303;
    
    public static final int keylines = 2130903309;
    
    public static final int lastBaselineToBottomHeight = 2130903311;
    
    public static final int layout = 2130903312;
    
    public static final int layout_anchor = 2130903314;
    
    public static final int layout_anchorGravity = 2130903315;
    
    public static final int layout_behavior = 2130903316;
    
    public static final int layout_dodgeInsetEdges = 2130903360;
    
    public static final int layout_insetEdge = 2130903369;
    
    public static final int layout_keyline = 2130903370;
    
    public static final int lineHeight = 2130903375;
    
    public static final int listChoiceBackgroundIndicator = 2130903377;
    
    public static final int listDividerAlertDialog = 2130903378;
    
    public static final int listItemLayout = 2130903379;
    
    public static final int listLayout = 2130903380;
    
    public static final int listMenuViewStyle = 2130903381;
    
    public static final int listPopupWindowStyle = 2130903382;
    
    public static final int listPreferredItemHeight = 2130903383;
    
    public static final int listPreferredItemHeightLarge = 2130903384;
    
    public static final int listPreferredItemHeightSmall = 2130903385;
    
    public static final int listPreferredItemPaddingLeft = 2130903386;
    
    public static final int listPreferredItemPaddingRight = 2130903387;
    
    public static final int logo = 2130903388;
    
    public static final int logoDescription = 2130903389;
    
    public static final int maxButtonHeight = 2130903393;
    
    public static final int measureWithLargestChild = 2130903395;
    
    public static final int multiChoiceItemLayout = 2130903397;
    
    public static final int navigationContentDescription = 2130903398;
    
    public static final int navigationIcon = 2130903399;
    
    public static final int navigationMode = 2130903400;
    
    public static final int numericModifiers = 2130903402;
    
    public static final int overlapAnchor = 2130903403;
    
    public static final int paddingBottomNoButtons = 2130903404;
    
    public static final int paddingEnd = 2130903405;
    
    public static final int paddingStart = 2130903406;
    
    public static final int paddingTopNoTitle = 2130903407;
    
    public static final int panelBackground = 2130903408;
    
    public static final int panelMenuListTheme = 2130903409;
    
    public static final int panelMenuListWidth = 2130903410;
    
    public static final int popupMenuStyle = 2130903416;
    
    public static final int popupTheme = 2130903417;
    
    public static final int popupWindowStyle = 2130903418;
    
    public static final int preserveIconSpacing = 2130903419;
    
    public static final int progressBarPadding = 2130903421;
    
    public static final int progressBarStyle = 2130903422;
    
    public static final int queryBackground = 2130903423;
    
    public static final int queryHint = 2130903424;
    
    public static final int radioButtonStyle = 2130903425;
    
    public static final int ratingBarStyle = 2130903426;
    
    public static final int ratingBarStyleIndicator = 2130903427;
    
    public static final int ratingBarStyleSmall = 2130903428;
    
    public static final int searchHintIcon = 2130903434;
    
    public static final int searchIcon = 2130903435;
    
    public static final int searchViewStyle = 2130903436;
    
    public static final int seekBarStyle = 2130903437;
    
    public static final int selectableItemBackground = 2130903438;
    
    public static final int selectableItemBackgroundBorderless = 2130903439;
    
    public static final int showAsAction = 2130903440;
    
    public static final int showDividers = 2130903441;
    
    public static final int showText = 2130903443;
    
    public static final int showTitle = 2130903444;
    
    public static final int singleChoiceItemLayout = 2130903445;
    
    public static final int spinBars = 2130903451;
    
    public static final int spinnerDropDownItemStyle = 2130903452;
    
    public static final int spinnerStyle = 2130903453;
    
    public static final int splitTrack = 2130903454;
    
    public static final int srcCompat = 2130903455;
    
    public static final int state_above_anchor = 2130903457;
    
    public static final int statusBarBackground = 2130903462;
    
    public static final int subMenuArrow = 2130903466;
    
    public static final int submitBackground = 2130903467;
    
    public static final int subtitle = 2130903468;
    
    public static final int subtitleTextAppearance = 2130903469;
    
    public static final int subtitleTextColor = 2130903470;
    
    public static final int subtitleTextStyle = 2130903471;
    
    public static final int suggestionRowLayout = 2130903472;
    
    public static final int switchMinWidth = 2130903473;
    
    public static final int switchPadding = 2130903474;
    
    public static final int switchStyle = 2130903475;
    
    public static final int switchTextAppearance = 2130903476;
    
    public static final int textAllCaps = 2130903503;
    
    public static final int textAppearanceLargePopupMenu = 2130903514;
    
    public static final int textAppearanceListItem = 2130903515;
    
    public static final int textAppearanceListItemSecondary = 2130903516;
    
    public static final int textAppearanceListItemSmall = 2130903517;
    
    public static final int textAppearancePopupMenuHeader = 2130903519;
    
    public static final int textAppearanceSearchResultSubtitle = 2130903520;
    
    public static final int textAppearanceSearchResultTitle = 2130903521;
    
    public static final int textAppearanceSmallPopupMenu = 2130903522;
    
    public static final int textColorAlertDialogListItem = 2130903525;
    
    public static final int textColorSearchUrl = 2130903526;
    
    public static final int theme = 2130903530;
    
    public static final int thickness = 2130903531;
    
    public static final int thumbTextPadding = 2130903532;
    
    public static final int thumbTint = 2130903533;
    
    public static final int thumbTintMode = 2130903534;
    
    public static final int tickMark = 2130903535;
    
    public static final int tickMarkTint = 2130903536;
    
    public static final int tickMarkTintMode = 2130903537;
    
    public static final int tint = 2130903538;
    
    public static final int tintMode = 2130903539;
    
    public static final int title = 2130903540;
    
    public static final int titleMargin = 2130903542;
    
    public static final int titleMarginBottom = 2130903543;
    
    public static final int titleMarginEnd = 2130903544;
    
    public static final int titleMarginStart = 2130903545;
    
    public static final int titleMarginTop = 2130903546;
    
    public static final int titleMargins = 2130903547;
    
    public static final int titleTextAppearance = 2130903548;
    
    public static final int titleTextColor = 2130903549;
    
    public static final int titleTextStyle = 2130903550;
    
    public static final int toolbarNavigationButtonStyle = 2130903552;
    
    public static final int toolbarStyle = 2130903553;
    
    public static final int tooltipForegroundColor = 2130903554;
    
    public static final int tooltipFrameBackground = 2130903555;
    
    public static final int tooltipText = 2130903556;
    
    public static final int track = 2130903557;
    
    public static final int trackTint = 2130903558;
    
    public static final int trackTintMode = 2130903559;
    
    public static final int ttcIndex = 2130903560;
    
    public static final int viewInflaterClass = 2130903562;
    
    public static final int voiceIcon = 2130903563;
    
    public static final int windowActionBar = 2130903564;
    
    public static final int windowActionBarOverlay = 2130903565;
    
    public static final int windowActionModeOverlay = 2130903566;
    
    public static final int windowFixedHeightMajor = 2130903567;
    
    public static final int windowFixedHeightMinor = 2130903568;
    
    public static final int windowFixedWidthMajor = 2130903569;
    
    public static final int windowFixedWidthMinor = 2130903570;
    
    public static final int windowMinWidthMajor = 2130903571;
    
    public static final int windowMinWidthMinor = 2130903572;
    
    public static final int windowNoTitle = 2130903573;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2130968576;
    
    public static final int abc_allow_stacked_button_bar = 2130968577;
    
    public static final int abc_config_actionMenuItemAllCaps = 2130968578;
  }
  
  public static final class color {
    public static final int abc_background_cache_hint_selector_material_dark = 2131034112;
    
    public static final int abc_background_cache_hint_selector_material_light = 2131034113;
    
    public static final int abc_btn_colored_borderless_text_material = 2131034114;
    
    public static final int abc_btn_colored_text_material = 2131034115;
    
    public static final int abc_color_highlight_material = 2131034116;
    
    public static final int abc_hint_foreground_material_dark = 2131034117;
    
    public static final int abc_hint_foreground_material_light = 2131034118;
    
    public static final int abc_input_method_navigation_guard = 2131034119;
    
    public static final int abc_primary_text_disable_only_material_dark = 2131034120;
    
    public static final int abc_primary_text_disable_only_material_light = 2131034121;
    
    public static final int abc_primary_text_material_dark = 2131034122;
    
    public static final int abc_primary_text_material_light = 2131034123;
    
    public static final int abc_search_url_text = 2131034124;
    
    public static final int abc_search_url_text_normal = 2131034125;
    
    public static final int abc_search_url_text_pressed = 2131034126;
    
    public static final int abc_search_url_text_selected = 2131034127;
    
    public static final int abc_secondary_text_material_dark = 2131034128;
    
    public static final int abc_secondary_text_material_light = 2131034129;
    
    public static final int abc_tint_btn_checkable = 2131034130;
    
    public static final int abc_tint_default = 2131034131;
    
    public static final int abc_tint_edittext = 2131034132;
    
    public static final int abc_tint_seek_thumb = 2131034133;
    
    public static final int abc_tint_spinner = 2131034134;
    
    public static final int abc_tint_switch_track = 2131034135;
    
    public static final int accent_material_dark = 2131034136;
    
    public static final int accent_material_light = 2131034137;
    
    public static final int background_floating_material_dark = 2131034138;
    
    public static final int background_floating_material_light = 2131034139;
    
    public static final int background_material_dark = 2131034140;
    
    public static final int background_material_light = 2131034141;
    
    public static final int bright_foreground_disabled_material_dark = 2131034142;
    
    public static final int bright_foreground_disabled_material_light = 2131034143;
    
    public static final int bright_foreground_inverse_material_dark = 2131034144;
    
    public static final int bright_foreground_inverse_material_light = 2131034145;
    
    public static final int bright_foreground_material_dark = 2131034146;
    
    public static final int bright_foreground_material_light = 2131034147;
    
    public static final int button_material_dark = 2131034148;
    
    public static final int button_material_light = 2131034149;
    
    public static final int dim_foreground_disabled_material_dark = 2131034170;
    
    public static final int dim_foreground_disabled_material_light = 2131034171;
    
    public static final int dim_foreground_material_dark = 2131034172;
    
    public static final int dim_foreground_material_light = 2131034173;
    
    public static final int error_color_material_dark = 2131034174;
    
    public static final int error_color_material_light = 2131034175;
    
    public static final int foreground_material_dark = 2131034176;
    
    public static final int foreground_material_light = 2131034177;
    
    public static final int highlighted_text_material_dark = 2131034178;
    
    public static final int highlighted_text_material_light = 2131034179;
    
    public static final int material_blue_grey_800 = 2131034182;
    
    public static final int material_blue_grey_900 = 2131034183;
    
    public static final int material_blue_grey_950 = 2131034184;
    
    public static final int material_deep_teal_200 = 2131034185;
    
    public static final int material_deep_teal_500 = 2131034186;
    
    public static final int material_grey_100 = 2131034187;
    
    public static final int material_grey_300 = 2131034188;
    
    public static final int material_grey_50 = 2131034189;
    
    public static final int material_grey_600 = 2131034190;
    
    public static final int material_grey_800 = 2131034191;
    
    public static final int material_grey_850 = 2131034192;
    
    public static final int material_grey_900 = 2131034193;
    
    public static final int notification_action_color_filter = 2131034220;
    
    public static final int notification_icon_bg_color = 2131034221;
    
    public static final int primary_dark_material_dark = 2131034222;
    
    public static final int primary_dark_material_light = 2131034223;
    
    public static final int primary_material_dark = 2131034224;
    
    public static final int primary_material_light = 2131034225;
    
    public static final int primary_text_default_material_dark = 2131034226;
    
    public static final int primary_text_default_material_light = 2131034227;
    
    public static final int primary_text_disabled_material_dark = 2131034228;
    
    public static final int primary_text_disabled_material_light = 2131034229;
    
    public static final int ripple_material_dark = 2131034230;
    
    public static final int ripple_material_light = 2131034231;
    
    public static final int secondary_text_default_material_dark = 2131034232;
    
    public static final int secondary_text_default_material_light = 2131034233;
    
    public static final int secondary_text_disabled_material_dark = 2131034234;
    
    public static final int secondary_text_disabled_material_light = 2131034235;
    
    public static final int switch_thumb_disabled_material_dark = 2131034236;
    
    public static final int switch_thumb_disabled_material_light = 2131034237;
    
    public static final int switch_thumb_material_dark = 2131034238;
    
    public static final int switch_thumb_material_light = 2131034239;
    
    public static final int switch_thumb_normal_material_dark = 2131034240;
    
    public static final int switch_thumb_normal_material_light = 2131034241;
    
    public static final int tooltip_background_dark = 2131034242;
    
    public static final int tooltip_background_light = 2131034243;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_content_inset_material = 2131099648;
    
    public static final int abc_action_bar_content_inset_with_nav = 2131099649;
    
    public static final int abc_action_bar_default_height_material = 2131099650;
    
    public static final int abc_action_bar_default_padding_end_material = 2131099651;
    
    public static final int abc_action_bar_default_padding_start_material = 2131099652;
    
    public static final int abc_action_bar_elevation_material = 2131099653;
    
    public static final int abc_action_bar_icon_vertical_padding_material = 2131099654;
    
    public static final int abc_action_bar_overflow_padding_end_material = 2131099655;
    
    public static final int abc_action_bar_overflow_padding_start_material = 2131099656;
    
    public static final int abc_action_bar_stacked_max_height = 2131099657;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131099658;
    
    public static final int abc_action_bar_subtitle_bottom_margin_material = 2131099659;
    
    public static final int abc_action_bar_subtitle_top_margin_material = 2131099660;
    
    public static final int abc_action_button_min_height_material = 2131099661;
    
    public static final int abc_action_button_min_width_material = 2131099662;
    
    public static final int abc_action_button_min_width_overflow_material = 2131099663;
    
    public static final int abc_alert_dialog_button_bar_height = 2131099664;
    
    public static final int abc_alert_dialog_button_dimen = 2131099665;
    
    public static final int abc_button_inset_horizontal_material = 2131099666;
    
    public static final int abc_button_inset_vertical_material = 2131099667;
    
    public static final int abc_button_padding_horizontal_material = 2131099668;
    
    public static final int abc_button_padding_vertical_material = 2131099669;
    
    public static final int abc_cascading_menus_min_smallest_width = 2131099670;
    
    public static final int abc_config_prefDialogWidth = 2131099671;
    
    public static final int abc_control_corner_material = 2131099672;
    
    public static final int abc_control_inset_material = 2131099673;
    
    public static final int abc_control_padding_material = 2131099674;
    
    public static final int abc_dialog_corner_radius_material = 2131099675;
    
    public static final int abc_dialog_fixed_height_major = 2131099676;
    
    public static final int abc_dialog_fixed_height_minor = 2131099677;
    
    public static final int abc_dialog_fixed_width_major = 2131099678;
    
    public static final int abc_dialog_fixed_width_minor = 2131099679;
    
    public static final int abc_dialog_list_padding_bottom_no_buttons = 2131099680;
    
    public static final int abc_dialog_list_padding_top_no_title = 2131099681;
    
    public static final int abc_dialog_min_width_major = 2131099682;
    
    public static final int abc_dialog_min_width_minor = 2131099683;
    
    public static final int abc_dialog_padding_material = 2131099684;
    
    public static final int abc_dialog_padding_top_material = 2131099685;
    
    public static final int abc_dialog_title_divider_material = 2131099686;
    
    public static final int abc_disabled_alpha_material_dark = 2131099687;
    
    public static final int abc_disabled_alpha_material_light = 2131099688;
    
    public static final int abc_dropdownitem_icon_width = 2131099689;
    
    public static final int abc_dropdownitem_text_padding_left = 2131099690;
    
    public static final int abc_dropdownitem_text_padding_right = 2131099691;
    
    public static final int abc_edit_text_inset_bottom_material = 2131099692;
    
    public static final int abc_edit_text_inset_horizontal_material = 2131099693;
    
    public static final int abc_edit_text_inset_top_material = 2131099694;
    
    public static final int abc_floating_window_z = 2131099695;
    
    public static final int abc_list_item_padding_horizontal_material = 2131099696;
    
    public static final int abc_panel_menu_list_width = 2131099697;
    
    public static final int abc_progress_bar_height_material = 2131099698;
    
    public static final int abc_search_view_preferred_height = 2131099699;
    
    public static final int abc_search_view_preferred_width = 2131099700;
    
    public static final int abc_seekbar_track_background_height_material = 2131099701;
    
    public static final int abc_seekbar_track_progress_height_material = 2131099702;
    
    public static final int abc_select_dialog_padding_start_material = 2131099703;
    
    public static final int abc_switch_padding = 2131099704;
    
    public static final int abc_text_size_body_1_material = 2131099705;
    
    public static final int abc_text_size_body_2_material = 2131099706;
    
    public static final int abc_text_size_button_material = 2131099707;
    
    public static final int abc_text_size_caption_material = 2131099708;
    
    public static final int abc_text_size_display_1_material = 2131099709;
    
    public static final int abc_text_size_display_2_material = 2131099710;
    
    public static final int abc_text_size_display_3_material = 2131099711;
    
    public static final int abc_text_size_display_4_material = 2131099712;
    
    public static final int abc_text_size_headline_material = 2131099713;
    
    public static final int abc_text_size_large_material = 2131099714;
    
    public static final int abc_text_size_medium_material = 2131099715;
    
    public static final int abc_text_size_menu_header_material = 2131099716;
    
    public static final int abc_text_size_menu_material = 2131099717;
    
    public static final int abc_text_size_small_material = 2131099718;
    
    public static final int abc_text_size_subhead_material = 2131099719;
    
    public static final int abc_text_size_subtitle_material_toolbar = 2131099720;
    
    public static final int abc_text_size_title_material = 2131099721;
    
    public static final int abc_text_size_title_material_toolbar = 2131099722;
    
    public static final int compat_button_inset_horizontal_material = 2131099726;
    
    public static final int compat_button_inset_vertical_material = 2131099727;
    
    public static final int compat_button_padding_horizontal_material = 2131099728;
    
    public static final int compat_button_padding_vertical_material = 2131099729;
    
    public static final int compat_control_corner_material = 2131099730;
    
    public static final int compat_notification_large_icon_max_height = 2131099731;
    
    public static final int compat_notification_large_icon_max_width = 2131099732;
    
    public static final int disabled_alpha_material_dark = 2131099777;
    
    public static final int disabled_alpha_material_light = 2131099778;
    
    public static final int highlight_alpha_material_colored = 2131099783;
    
    public static final int highlight_alpha_material_dark = 2131099784;
    
    public static final int highlight_alpha_material_light = 2131099785;
    
    public static final int hint_alpha_material_dark = 2131099786;
    
    public static final int hint_alpha_material_light = 2131099787;
    
    public static final int hint_pressed_alpha_material_dark = 2131099788;
    
    public static final int hint_pressed_alpha_material_light = 2131099789;
    
    public static final int notification_action_icon_size = 2131099841;
    
    public static final int notification_action_text_size = 2131099842;
    
    public static final int notification_big_circle_margin = 2131099843;
    
    public static final int notification_content_margin_start = 2131099844;
    
    public static final int notification_large_icon_height = 2131099845;
    
    public static final int notification_large_icon_width = 2131099846;
    
    public static final int notification_main_column_padding_top = 2131099847;
    
    public static final int notification_media_narrow_margin = 2131099848;
    
    public static final int notification_right_icon_size = 2131099849;
    
    public static final int notification_right_side_padding_top = 2131099850;
    
    public static final int notification_small_icon_background_padding = 2131099851;
    
    public static final int notification_small_icon_size_as_large = 2131099852;
    
    public static final int notification_subtext_size = 2131099853;
    
    public static final int notification_top_pad = 2131099854;
    
    public static final int notification_top_pad_large_text = 2131099855;
    
    public static final int tooltip_corner_radius = 2131099856;
    
    public static final int tooltip_horizontal_padding = 2131099857;
    
    public static final int tooltip_margin = 2131099858;
    
    public static final int tooltip_precise_anchor_extra_offset = 2131099859;
    
    public static final int tooltip_precise_anchor_threshold = 2131099860;
    
    public static final int tooltip_vertical_padding = 2131099861;
    
    public static final int tooltip_y_offset_non_touch = 2131099862;
    
    public static final int tooltip_y_offset_touch = 2131099863;
  }
  
  public static final class drawable {
    public static final int abc_ab_share_pack_mtrl_alpha = 2131165191;
    
    public static final int abc_action_bar_item_background_material = 2131165192;
    
    public static final int abc_btn_borderless_material = 2131165193;
    
    public static final int abc_btn_check_material = 2131165194;
    
    public static final int abc_btn_check_to_on_mtrl_000 = 2131165195;
    
    public static final int abc_btn_check_to_on_mtrl_015 = 2131165196;
    
    public static final int abc_btn_colored_material = 2131165197;
    
    public static final int abc_btn_default_mtrl_shape = 2131165198;
    
    public static final int abc_btn_radio_material = 2131165199;
    
    public static final int abc_btn_radio_to_on_mtrl_000 = 2131165200;
    
    public static final int abc_btn_radio_to_on_mtrl_015 = 2131165201;
    
    public static final int abc_btn_switch_to_on_mtrl_00001 = 2131165202;
    
    public static final int abc_btn_switch_to_on_mtrl_00012 = 2131165203;
    
    public static final int abc_cab_background_internal_bg = 2131165204;
    
    public static final int abc_cab_background_top_material = 2131165205;
    
    public static final int abc_cab_background_top_mtrl_alpha = 2131165206;
    
    public static final int abc_control_background_material = 2131165207;
    
    public static final int abc_dialog_material_background = 2131165208;
    
    public static final int abc_edit_text_material = 2131165209;
    
    public static final int abc_ic_ab_back_material = 2131165210;
    
    public static final int abc_ic_arrow_drop_right_black_24dp = 2131165211;
    
    public static final int abc_ic_clear_material = 2131165212;
    
    public static final int abc_ic_commit_search_api_mtrl_alpha = 2131165213;
    
    public static final int abc_ic_go_search_api_material = 2131165214;
    
    public static final int abc_ic_menu_copy_mtrl_am_alpha = 2131165215;
    
    public static final int abc_ic_menu_cut_mtrl_alpha = 2131165216;
    
    public static final int abc_ic_menu_overflow_material = 2131165217;
    
    public static final int abc_ic_menu_paste_mtrl_am_alpha = 2131165218;
    
    public static final int abc_ic_menu_selectall_mtrl_alpha = 2131165219;
    
    public static final int abc_ic_menu_share_mtrl_alpha = 2131165220;
    
    public static final int abc_ic_search_api_material = 2131165221;
    
    public static final int abc_ic_star_black_16dp = 2131165222;
    
    public static final int abc_ic_star_black_36dp = 2131165223;
    
    public static final int abc_ic_star_black_48dp = 2131165224;
    
    public static final int abc_ic_star_half_black_16dp = 2131165225;
    
    public static final int abc_ic_star_half_black_36dp = 2131165226;
    
    public static final int abc_ic_star_half_black_48dp = 2131165227;
    
    public static final int abc_ic_voice_search_api_material = 2131165228;
    
    public static final int abc_item_background_holo_dark = 2131165229;
    
    public static final int abc_item_background_holo_light = 2131165230;
    
    public static final int abc_list_divider_material = 2131165231;
    
    public static final int abc_list_divider_mtrl_alpha = 2131165232;
    
    public static final int abc_list_focused_holo = 2131165233;
    
    public static final int abc_list_longpressed_holo = 2131165234;
    
    public static final int abc_list_pressed_holo_dark = 2131165235;
    
    public static final int abc_list_pressed_holo_light = 2131165236;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2131165237;
    
    public static final int abc_list_selector_background_transition_holo_light = 2131165238;
    
    public static final int abc_list_selector_disabled_holo_dark = 2131165239;
    
    public static final int abc_list_selector_disabled_holo_light = 2131165240;
    
    public static final int abc_list_selector_holo_dark = 2131165241;
    
    public static final int abc_list_selector_holo_light = 2131165242;
    
    public static final int abc_menu_hardkey_panel_mtrl_mult = 2131165243;
    
    public static final int abc_popup_background_mtrl_mult = 2131165244;
    
    public static final int abc_ratingbar_indicator_material = 2131165245;
    
    public static final int abc_ratingbar_material = 2131165246;
    
    public static final int abc_ratingbar_small_material = 2131165247;
    
    public static final int abc_scrubber_control_off_mtrl_alpha = 2131165248;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_000 = 2131165249;
    
    public static final int abc_scrubber_control_to_pressed_mtrl_005 = 2131165250;
    
    public static final int abc_scrubber_primary_mtrl_alpha = 2131165251;
    
    public static final int abc_scrubber_track_mtrl_alpha = 2131165252;
    
    public static final int abc_seekbar_thumb_material = 2131165253;
    
    public static final int abc_seekbar_tick_mark_material = 2131165254;
    
    public static final int abc_seekbar_track_material = 2131165255;
    
    public static final int abc_spinner_mtrl_am_alpha = 2131165256;
    
    public static final int abc_spinner_textfield_background_material = 2131165257;
    
    public static final int abc_switch_thumb_material = 2131165258;
    
    public static final int abc_switch_track_mtrl_alpha = 2131165259;
    
    public static final int abc_tab_indicator_material = 2131165260;
    
    public static final int abc_tab_indicator_mtrl_alpha = 2131165261;
    
    public static final int abc_text_cursor_material = 2131165262;
    
    public static final int abc_text_select_handle_left_mtrl_dark = 2131165263;
    
    public static final int abc_text_select_handle_left_mtrl_light = 2131165264;
    
    public static final int abc_text_select_handle_middle_mtrl_dark = 2131165265;
    
    public static final int abc_text_select_handle_middle_mtrl_light = 2131165266;
    
    public static final int abc_text_select_handle_right_mtrl_dark = 2131165267;
    
    public static final int abc_text_select_handle_right_mtrl_light = 2131165268;
    
    public static final int abc_textfield_activated_mtrl_alpha = 2131165269;
    
    public static final int abc_textfield_default_mtrl_alpha = 2131165270;
    
    public static final int abc_textfield_search_activated_mtrl_alpha = 2131165271;
    
    public static final int abc_textfield_search_default_mtrl_alpha = 2131165272;
    
    public static final int abc_textfield_search_material = 2131165273;
    
    public static final int abc_vector_test = 2131165274;
    
    public static final int notification_action_background = 2131165298;
    
    public static final int notification_bg = 2131165299;
    
    public static final int notification_bg_low = 2131165300;
    
    public static final int notification_bg_low_normal = 2131165301;
    
    public static final int notification_bg_low_pressed = 2131165302;
    
    public static final int notification_bg_normal = 2131165303;
    
    public static final int notification_bg_normal_pressed = 2131165304;
    
    public static final int notification_icon_background = 2131165305;
    
    public static final int notification_template_icon_bg = 2131165306;
    
    public static final int notification_template_icon_low_bg = 2131165307;
    
    public static final int notification_tile_bg = 2131165308;
    
    public static final int notify_panel_notification_icon_bg = 2131165309;
    
    public static final int tooltip_frame_dark = 2131165310;
    
    public static final int tooltip_frame_light = 2131165311;
  }
  
  public static final class id {
    public static final int action_bar = 2131230726;
    
    public static final int action_bar_activity_content = 2131230727;
    
    public static final int action_bar_container = 2131230728;
    
    public static final int action_bar_root = 2131230729;
    
    public static final int action_bar_spinner = 2131230730;
    
    public static final int action_bar_subtitle = 2131230731;
    
    public static final int action_bar_title = 2131230732;
    
    public static final int action_container = 2131230733;
    
    public static final int action_context_bar = 2131230734;
    
    public static final int action_divider = 2131230735;
    
    public static final int action_image = 2131230736;
    
    public static final int action_menu_divider = 2131230737;
    
    public static final int action_menu_presenter = 2131230738;
    
    public static final int action_mode_bar = 2131230739;
    
    public static final int action_mode_bar_stub = 2131230740;
    
    public static final int action_mode_close_button = 2131230741;
    
    public static final int action_text = 2131230742;
    
    public static final int actions = 2131230743;
    
    public static final int activity_chooser_view_content = 2131230744;
    
    public static final int add = 2131230745;
    
    public static final int alertTitle = 2131230746;
    
    public static final int async = 2131230749;
    
    public static final int blocking = 2131230753;
    
    public static final int bottom = 2131230754;
    
    public static final int buttonPanel = 2131230755;
    
    public static final int checkbox = 2131230760;
    
    public static final int chronometer = 2131230761;
    
    public static final int content = 2131230766;
    
    public static final int contentPanel = 2131230767;
    
    public static final int custom = 2131230769;
    
    public static final int customPanel = 2131230770;
    
    public static final int decor_content_parent = 2131230771;
    
    public static final int default_activity_button = 2131230772;
    
    public static final int edit_query = 2131230782;
    
    public static final int end = 2131230783;
    
    public static final int expand_activities_button = 2131230787;
    
    public static final int expanded_menu = 2131230788;
    
    public static final int forever = 2131230795;
    
    public static final int group_divider = 2131230798;
    
    public static final int home = 2131230802;
    
    public static final int icon = 2131230804;
    
    public static final int icon_group = 2131230805;
    
    public static final int image = 2131230807;
    
    public static final int info = 2131230808;
    
    public static final int italic = 2131230810;
    
    public static final int left = 2131230823;
    
    public static final int line1 = 2131230824;
    
    public static final int line3 = 2131230825;
    
    public static final int listMode = 2131230826;
    
    public static final int list_item = 2131230827;
    
    public static final int message = 2131230830;
    
    public static final int multiply = 2131230835;
    
    public static final int none = 2131230838;
    
    public static final int normal = 2131230839;
    
    public static final int notification_background = 2131230840;
    
    public static final int notification_main_column = 2131230841;
    
    public static final int notification_main_column_container = 2131230842;
    
    public static final int parentPanel = 2131230847;
    
    public static final int progress_circular = 2131230851;
    
    public static final int progress_horizontal = 2131230852;
    
    public static final int radio = 2131230853;
    
    public static final int right = 2131230854;
    
    public static final int right_icon = 2131230855;
    
    public static final int right_side = 2131230856;
    
    public static final int screen = 2131230860;
    
    public static final int scrollIndicatorDown = 2131230862;
    
    public static final int scrollIndicatorUp = 2131230863;
    
    public static final int scrollView = 2131230864;
    
    public static final int search_badge = 2131230866;
    
    public static final int search_bar = 2131230867;
    
    public static final int search_button = 2131230868;
    
    public static final int search_close_btn = 2131230869;
    
    public static final int search_edit_frame = 2131230870;
    
    public static final int search_go_btn = 2131230871;
    
    public static final int search_mag_icon = 2131230872;
    
    public static final int search_plate = 2131230873;
    
    public static final int search_src_text = 2131230874;
    
    public static final int search_voice_btn = 2131230875;
    
    public static final int select_dialog_listview = 2131230876;
    
    public static final int shortcut = 2131230878;
    
    public static final int spacer = 2131230887;
    
    public static final int split_action_bar = 2131230888;
    
    public static final int src_atop = 2131230891;
    
    public static final int src_in = 2131230892;
    
    public static final int src_over = 2131230893;
    
    public static final int start = 2131230895;
    
    public static final int submenuarrow = 2131230897;
    
    public static final int submit_area = 2131230898;
    
    public static final int tabMode = 2131230899;
    
    public static final int tag_transition_group = 2131230900;
    
    public static final int tag_unhandled_key_event_manager = 2131230901;
    
    public static final int tag_unhandled_key_listeners = 2131230902;
    
    public static final int text = 2131230903;
    
    public static final int text2 = 2131230904;
    
    public static final int textSpacerNoButtons = 2131230905;
    
    public static final int textSpacerNoTitle = 2131230906;
    
    public static final int time = 2131230920;
    
    public static final int title = 2131230921;
    
    public static final int titleDividerNoCustom = 2131230922;
    
    public static final int title_template = 2131230923;
    
    public static final int top = 2131230926;
    
    public static final int topPanel = 2131230927;
    
    public static final int uniform = 2131230934;
    
    public static final int up = 2131230936;
    
    public static final int wrap_content = 2131230942;
  }
  
  public static final class integer {
    public static final int abc_config_activityDefaultDur = 2131296256;
    
    public static final int abc_config_activityShortDur = 2131296257;
    
    public static final int cancel_button_image_alpha = 2131296260;
    
    public static final int config_tooltipAnimTime = 2131296261;
    
    public static final int status_bar_notification_info_maxnum = 2131296270;
  }
  
  public static final class layout {
    public static final int abc_action_bar_title_item = 2131427328;
    
    public static final int abc_action_bar_up_container = 2131427329;
    
    public static final int abc_action_menu_item_layout = 2131427330;
    
    public static final int abc_action_menu_layout = 2131427331;
    
    public static final int abc_action_mode_bar = 2131427332;
    
    public static final int abc_action_mode_close_item_material = 2131427333;
    
    public static final int abc_activity_chooser_view = 2131427334;
    
    public static final int abc_activity_chooser_view_list_item = 2131427335;
    
    public static final int abc_alert_dialog_button_bar_material = 2131427336;
    
    public static final int abc_alert_dialog_material = 2131427337;
    
    public static final int abc_alert_dialog_title_material = 2131427338;
    
    public static final int abc_cascading_menu_item_layout = 2131427339;
    
    public static final int abc_dialog_title_material = 2131427340;
    
    public static final int abc_expanded_menu_layout = 2131427341;
    
    public static final int abc_list_menu_item_checkbox = 2131427342;
    
    public static final int abc_list_menu_item_icon = 2131427343;
    
    public static final int abc_list_menu_item_layout = 2131427344;
    
    public static final int abc_list_menu_item_radio = 2131427345;
    
    public static final int abc_popup_menu_header_item_layout = 2131427346;
    
    public static final int abc_popup_menu_item_layout = 2131427347;
    
    public static final int abc_screen_content_include = 2131427348;
    
    public static final int abc_screen_simple = 2131427349;
    
    public static final int abc_screen_simple_overlay_action_mode = 2131427350;
    
    public static final int abc_screen_toolbar = 2131427351;
    
    public static final int abc_search_dropdown_item_icons_2line = 2131427352;
    
    public static final int abc_search_view = 2131427353;
    
    public static final int abc_select_dialog_material = 2131427354;
    
    public static final int abc_tooltip = 2131427355;
    
    public static final int notification_action = 2131427386;
    
    public static final int notification_action_tombstone = 2131427387;
    
    public static final int notification_template_custom_big = 2131427388;
    
    public static final int notification_template_icon_group = 2131427389;
    
    public static final int notification_template_part_chronometer = 2131427390;
    
    public static final int notification_template_part_time = 2131427391;
    
    public static final int select_dialog_item_material = 2131427392;
    
    public static final int select_dialog_multichoice_material = 2131427393;
    
    public static final int select_dialog_singlechoice_material = 2131427394;
    
    public static final int support_simple_spinner_dropdown_item = 2131427395;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131558400;
    
    public static final int abc_action_bar_up_description = 2131558401;
    
    public static final int abc_action_menu_overflow_description = 2131558402;
    
    public static final int abc_action_mode_done = 2131558403;
    
    public static final int abc_activity_chooser_view_see_all = 2131558404;
    
    public static final int abc_activitychooserview_choose_application = 2131558405;
    
    public static final int abc_capital_off = 2131558406;
    
    public static final int abc_capital_on = 2131558407;
    
    public static final int abc_font_family_body_1_material = 2131558408;
    
    public static final int abc_font_family_body_2_material = 2131558409;
    
    public static final int abc_font_family_button_material = 2131558410;
    
    public static final int abc_font_family_caption_material = 2131558411;
    
    public static final int abc_font_family_display_1_material = 2131558412;
    
    public static final int abc_font_family_display_2_material = 2131558413;
    
    public static final int abc_font_family_display_3_material = 2131558414;
    
    public static final int abc_font_family_display_4_material = 2131558415;
    
    public static final int abc_font_family_headline_material = 2131558416;
    
    public static final int abc_font_family_menu_material = 2131558417;
    
    public static final int abc_font_family_subhead_material = 2131558418;
    
    public static final int abc_font_family_title_material = 2131558419;
    
    public static final int abc_menu_alt_shortcut_label = 2131558420;
    
    public static final int abc_menu_ctrl_shortcut_label = 2131558421;
    
    public static final int abc_menu_delete_shortcut_label = 2131558422;
    
    public static final int abc_menu_enter_shortcut_label = 2131558423;
    
    public static final int abc_menu_function_shortcut_label = 2131558424;
    
    public static final int abc_menu_meta_shortcut_label = 2131558425;
    
    public static final int abc_menu_shift_shortcut_label = 2131558426;
    
    public static final int abc_menu_space_shortcut_label = 2131558427;
    
    public static final int abc_menu_sym_shortcut_label = 2131558428;
    
    public static final int abc_prepend_shortcut_label = 2131558429;
    
    public static final int abc_search_hint = 2131558430;
    
    public static final int abc_searchview_description_clear = 2131558431;
    
    public static final int abc_searchview_description_query = 2131558432;
    
    public static final int abc_searchview_description_search = 2131558433;
    
    public static final int abc_searchview_description_submit = 2131558434;
    
    public static final int abc_searchview_description_voice = 2131558435;
    
    public static final int abc_shareactionprovider_share_with = 2131558436;
    
    public static final int abc_shareactionprovider_share_with_application = 2131558437;
    
    public static final int abc_toolbar_collapse_description = 2131558438;
    
    public static final int search_menu_title = 2131558454;
    
    public static final int status_bar_notification_info_overflow = 2131558455;
  }
  
  public static final class style {
    public static final int AlertDialog_AppCompat = 2131623936;
    
    public static final int AlertDialog_AppCompat_Light = 2131623937;
    
    public static final int Animation_AppCompat_Dialog = 2131623938;
    
    public static final int Animation_AppCompat_DropDownUp = 2131623939;
    
    public static final int Animation_AppCompat_Tooltip = 2131623940;
    
    public static final int Base_AlertDialog_AppCompat = 2131623946;
    
    public static final int Base_AlertDialog_AppCompat_Light = 2131623947;
    
    public static final int Base_Animation_AppCompat_Dialog = 2131623948;
    
    public static final int Base_Animation_AppCompat_DropDownUp = 2131623949;
    
    public static final int Base_Animation_AppCompat_Tooltip = 2131623950;
    
    public static final int Base_DialogWindowTitleBackground_AppCompat = 2131623953;
    
    public static final int Base_DialogWindowTitle_AppCompat = 2131623952;
    
    public static final int Base_TextAppearance_AppCompat = 2131623954;
    
    public static final int Base_TextAppearance_AppCompat_Body1 = 2131623955;
    
    public static final int Base_TextAppearance_AppCompat_Body2 = 2131623956;
    
    public static final int Base_TextAppearance_AppCompat_Button = 2131623957;
    
    public static final int Base_TextAppearance_AppCompat_Caption = 2131623958;
    
    public static final int Base_TextAppearance_AppCompat_Display1 = 2131623959;
    
    public static final int Base_TextAppearance_AppCompat_Display2 = 2131623960;
    
    public static final int Base_TextAppearance_AppCompat_Display3 = 2131623961;
    
    public static final int Base_TextAppearance_AppCompat_Display4 = 2131623962;
    
    public static final int Base_TextAppearance_AppCompat_Headline = 2131623963;
    
    public static final int Base_TextAppearance_AppCompat_Inverse = 2131623964;
    
    public static final int Base_TextAppearance_AppCompat_Large = 2131623965;
    
    public static final int Base_TextAppearance_AppCompat_Large_Inverse = 2131623966;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131623967;
    
    public static final int Base_TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131623968;
    
    public static final int Base_TextAppearance_AppCompat_Medium = 2131623969;
    
    public static final int Base_TextAppearance_AppCompat_Medium_Inverse = 2131623970;
    
    public static final int Base_TextAppearance_AppCompat_Menu = 2131623971;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult = 2131623972;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Subtitle = 2131623973;
    
    public static final int Base_TextAppearance_AppCompat_SearchResult_Title = 2131623974;
    
    public static final int Base_TextAppearance_AppCompat_Small = 2131623975;
    
    public static final int Base_TextAppearance_AppCompat_Small_Inverse = 2131623976;
    
    public static final int Base_TextAppearance_AppCompat_Subhead = 2131623977;
    
    public static final int Base_TextAppearance_AppCompat_Subhead_Inverse = 2131623978;
    
    public static final int Base_TextAppearance_AppCompat_Title = 2131623979;
    
    public static final int Base_TextAppearance_AppCompat_Title_Inverse = 2131623980;
    
    public static final int Base_TextAppearance_AppCompat_Tooltip = 2131623981;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131623982;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131623983;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131623984;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title = 2131623985;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131623986;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131623987;
    
    public static final int Base_TextAppearance_AppCompat_Widget_ActionMode_Title = 2131623988;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button = 2131623989;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131623990;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Colored = 2131623991;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Button_Inverse = 2131623992;
    
    public static final int Base_TextAppearance_AppCompat_Widget_DropDownItem = 2131623993;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131623994;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131623995;
    
    public static final int Base_TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131623996;
    
    public static final int Base_TextAppearance_AppCompat_Widget_Switch = 2131623997;
    
    public static final int Base_TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131623998;
    
    public static final int Base_TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131623999;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131624000;
    
    public static final int Base_TextAppearance_Widget_AppCompat_Toolbar_Title = 2131624001;
    
    public static final int Base_ThemeOverlay_AppCompat = 2131624033;
    
    public static final int Base_ThemeOverlay_AppCompat_ActionBar = 2131624034;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark = 2131624035;
    
    public static final int Base_ThemeOverlay_AppCompat_Dark_ActionBar = 2131624036;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog = 2131624037;
    
    public static final int Base_ThemeOverlay_AppCompat_Dialog_Alert = 2131624038;
    
    public static final int Base_ThemeOverlay_AppCompat_Light = 2131624039;
    
    public static final int Base_Theme_AppCompat = 2131624002;
    
    public static final int Base_Theme_AppCompat_CompactMenu = 2131624003;
    
    public static final int Base_Theme_AppCompat_Dialog = 2131624004;
    
    public static final int Base_Theme_AppCompat_DialogWhenLarge = 2131624008;
    
    public static final int Base_Theme_AppCompat_Dialog_Alert = 2131624005;
    
    public static final int Base_Theme_AppCompat_Dialog_FixedSize = 2131624006;
    
    public static final int Base_Theme_AppCompat_Dialog_MinWidth = 2131624007;
    
    public static final int Base_Theme_AppCompat_Light = 2131624009;
    
    public static final int Base_Theme_AppCompat_Light_DarkActionBar = 2131624010;
    
    public static final int Base_Theme_AppCompat_Light_Dialog = 2131624011;
    
    public static final int Base_Theme_AppCompat_Light_DialogWhenLarge = 2131624015;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_Alert = 2131624012;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_FixedSize = 2131624013;
    
    public static final int Base_Theme_AppCompat_Light_Dialog_MinWidth = 2131624014;
    
    public static final int Base_V21_ThemeOverlay_AppCompat_Dialog = 2131624055;
    
    public static final int Base_V21_Theme_AppCompat = 2131624051;
    
    public static final int Base_V21_Theme_AppCompat_Dialog = 2131624052;
    
    public static final int Base_V21_Theme_AppCompat_Light = 2131624053;
    
    public static final int Base_V21_Theme_AppCompat_Light_Dialog = 2131624054;
    
    public static final int Base_V22_Theme_AppCompat = 2131624056;
    
    public static final int Base_V22_Theme_AppCompat_Light = 2131624057;
    
    public static final int Base_V23_Theme_AppCompat = 2131624058;
    
    public static final int Base_V23_Theme_AppCompat_Light = 2131624059;
    
    public static final int Base_V26_Theme_AppCompat = 2131624060;
    
    public static final int Base_V26_Theme_AppCompat_Light = 2131624061;
    
    public static final int Base_V26_Widget_AppCompat_Toolbar = 2131624062;
    
    public static final int Base_V28_Theme_AppCompat = 2131624063;
    
    public static final int Base_V28_Theme_AppCompat_Light = 2131624064;
    
    public static final int Base_V7_ThemeOverlay_AppCompat_Dialog = 2131624069;
    
    public static final int Base_V7_Theme_AppCompat = 2131624065;
    
    public static final int Base_V7_Theme_AppCompat_Dialog = 2131624066;
    
    public static final int Base_V7_Theme_AppCompat_Light = 2131624067;
    
    public static final int Base_V7_Theme_AppCompat_Light_Dialog = 2131624068;
    
    public static final int Base_V7_Widget_AppCompat_AutoCompleteTextView = 2131624070;
    
    public static final int Base_V7_Widget_AppCompat_EditText = 2131624071;
    
    public static final int Base_V7_Widget_AppCompat_Toolbar = 2131624072;
    
    public static final int Base_Widget_AppCompat_ActionBar = 2131624073;
    
    public static final int Base_Widget_AppCompat_ActionBar_Solid = 2131624074;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabBar = 2131624075;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabText = 2131624076;
    
    public static final int Base_Widget_AppCompat_ActionBar_TabView = 2131624077;
    
    public static final int Base_Widget_AppCompat_ActionButton = 2131624078;
    
    public static final int Base_Widget_AppCompat_ActionButton_CloseMode = 2131624079;
    
    public static final int Base_Widget_AppCompat_ActionButton_Overflow = 2131624080;
    
    public static final int Base_Widget_AppCompat_ActionMode = 2131624081;
    
    public static final int Base_Widget_AppCompat_ActivityChooserView = 2131624082;
    
    public static final int Base_Widget_AppCompat_AutoCompleteTextView = 2131624083;
    
    public static final int Base_Widget_AppCompat_Button = 2131624084;
    
    public static final int Base_Widget_AppCompat_ButtonBar = 2131624090;
    
    public static final int Base_Widget_AppCompat_ButtonBar_AlertDialog = 2131624091;
    
    public static final int Base_Widget_AppCompat_Button_Borderless = 2131624085;
    
    public static final int Base_Widget_AppCompat_Button_Borderless_Colored = 2131624086;
    
    public static final int Base_Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131624087;
    
    public static final int Base_Widget_AppCompat_Button_Colored = 2131624088;
    
    public static final int Base_Widget_AppCompat_Button_Small = 2131624089;
    
    public static final int Base_Widget_AppCompat_CompoundButton_CheckBox = 2131624092;
    
    public static final int Base_Widget_AppCompat_CompoundButton_RadioButton = 2131624093;
    
    public static final int Base_Widget_AppCompat_CompoundButton_Switch = 2131624094;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle = 2131624095;
    
    public static final int Base_Widget_AppCompat_DrawerArrowToggle_Common = 2131624096;
    
    public static final int Base_Widget_AppCompat_DropDownItem_Spinner = 2131624097;
    
    public static final int Base_Widget_AppCompat_EditText = 2131624098;
    
    public static final int Base_Widget_AppCompat_ImageButton = 2131624099;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar = 2131624100;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_Solid = 2131624101;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabBar = 2131624102;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText = 2131624103;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131624104;
    
    public static final int Base_Widget_AppCompat_Light_ActionBar_TabView = 2131624105;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu = 2131624106;
    
    public static final int Base_Widget_AppCompat_Light_PopupMenu_Overflow = 2131624107;
    
    public static final int Base_Widget_AppCompat_ListMenuView = 2131624108;
    
    public static final int Base_Widget_AppCompat_ListPopupWindow = 2131624109;
    
    public static final int Base_Widget_AppCompat_ListView = 2131624110;
    
    public static final int Base_Widget_AppCompat_ListView_DropDown = 2131624111;
    
    public static final int Base_Widget_AppCompat_ListView_Menu = 2131624112;
    
    public static final int Base_Widget_AppCompat_PopupMenu = 2131624113;
    
    public static final int Base_Widget_AppCompat_PopupMenu_Overflow = 2131624114;
    
    public static final int Base_Widget_AppCompat_PopupWindow = 2131624115;
    
    public static final int Base_Widget_AppCompat_ProgressBar = 2131624116;
    
    public static final int Base_Widget_AppCompat_ProgressBar_Horizontal = 2131624117;
    
    public static final int Base_Widget_AppCompat_RatingBar = 2131624118;
    
    public static final int Base_Widget_AppCompat_RatingBar_Indicator = 2131624119;
    
    public static final int Base_Widget_AppCompat_RatingBar_Small = 2131624120;
    
    public static final int Base_Widget_AppCompat_SearchView = 2131624121;
    
    public static final int Base_Widget_AppCompat_SearchView_ActionBar = 2131624122;
    
    public static final int Base_Widget_AppCompat_SeekBar = 2131624123;
    
    public static final int Base_Widget_AppCompat_SeekBar_Discrete = 2131624124;
    
    public static final int Base_Widget_AppCompat_Spinner = 2131624125;
    
    public static final int Base_Widget_AppCompat_Spinner_Underlined = 2131624126;
    
    public static final int Base_Widget_AppCompat_TextView_SpinnerItem = 2131624127;
    
    public static final int Base_Widget_AppCompat_Toolbar = 2131624128;
    
    public static final int Base_Widget_AppCompat_Toolbar_Button_Navigation = 2131624129;
    
    public static final int Platform_AppCompat = 2131624137;
    
    public static final int Platform_AppCompat_Light = 2131624138;
    
    public static final int Platform_ThemeOverlay_AppCompat = 2131624143;
    
    public static final int Platform_ThemeOverlay_AppCompat_Dark = 2131624144;
    
    public static final int Platform_ThemeOverlay_AppCompat_Light = 2131624145;
    
    public static final int Platform_V21_AppCompat = 2131624146;
    
    public static final int Platform_V21_AppCompat_Light = 2131624147;
    
    public static final int Platform_V25_AppCompat = 2131624148;
    
    public static final int Platform_V25_AppCompat_Light = 2131624149;
    
    public static final int Platform_Widget_AppCompat_Spinner = 2131624150;
    
    public static final int RtlOverlay_DialogWindowTitle_AppCompat = 2131624151;
    
    public static final int RtlOverlay_Widget_AppCompat_ActionBar_TitleItem = 2131624152;
    
    public static final int RtlOverlay_Widget_AppCompat_DialogTitle_Icon = 2131624153;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem = 2131624154;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_InternalGroup = 2131624155;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Shortcut = 2131624156;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_SubmenuArrow = 2131624157;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Text = 2131624158;
    
    public static final int RtlOverlay_Widget_AppCompat_PopupMenuItem_Title = 2131624159;
    
    public static final int RtlOverlay_Widget_AppCompat_SearchView_MagIcon = 2131624165;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown = 2131624160;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon1 = 2131624161;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Icon2 = 2131624162;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Query = 2131624163;
    
    public static final int RtlOverlay_Widget_AppCompat_Search_DropDown_Text = 2131624164;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton = 2131624166;
    
    public static final int RtlUnderlay_Widget_AppCompat_ActionButton_Overflow = 2131624167;
    
    public static final int TextAppearance_AppCompat = 2131624168;
    
    public static final int TextAppearance_AppCompat_Body1 = 2131624169;
    
    public static final int TextAppearance_AppCompat_Body2 = 2131624170;
    
    public static final int TextAppearance_AppCompat_Button = 2131624171;
    
    public static final int TextAppearance_AppCompat_Caption = 2131624172;
    
    public static final int TextAppearance_AppCompat_Display1 = 2131624173;
    
    public static final int TextAppearance_AppCompat_Display2 = 2131624174;
    
    public static final int TextAppearance_AppCompat_Display3 = 2131624175;
    
    public static final int TextAppearance_AppCompat_Display4 = 2131624176;
    
    public static final int TextAppearance_AppCompat_Headline = 2131624177;
    
    public static final int TextAppearance_AppCompat_Inverse = 2131624178;
    
    public static final int TextAppearance_AppCompat_Large = 2131624179;
    
    public static final int TextAppearance_AppCompat_Large_Inverse = 2131624180;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131624181;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131624182;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131624183;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131624184;
    
    public static final int TextAppearance_AppCompat_Medium = 2131624185;
    
    public static final int TextAppearance_AppCompat_Medium_Inverse = 2131624186;
    
    public static final int TextAppearance_AppCompat_Menu = 2131624187;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131624188;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131624189;
    
    public static final int TextAppearance_AppCompat_Small = 2131624190;
    
    public static final int TextAppearance_AppCompat_Small_Inverse = 2131624191;
    
    public static final int TextAppearance_AppCompat_Subhead = 2131624192;
    
    public static final int TextAppearance_AppCompat_Subhead_Inverse = 2131624193;
    
    public static final int TextAppearance_AppCompat_Title = 2131624194;
    
    public static final int TextAppearance_AppCompat_Title_Inverse = 2131624195;
    
    public static final int TextAppearance_AppCompat_Tooltip = 2131624196;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131624197;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131624198;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131624199;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131624200;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131624201;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131624202;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131624203;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131624204;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131624205;
    
    public static final int TextAppearance_AppCompat_Widget_Button = 2131624206;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Borderless_Colored = 2131624207;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Colored = 2131624208;
    
    public static final int TextAppearance_AppCompat_Widget_Button_Inverse = 2131624209;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131624210;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Header = 2131624211;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131624212;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131624213;
    
    public static final int TextAppearance_AppCompat_Widget_Switch = 2131624214;
    
    public static final int TextAppearance_AppCompat_Widget_TextView_SpinnerItem = 2131624215;
    
    public static final int TextAppearance_Compat_Notification = 2131624216;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131624217;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131624218;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131624219;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131624220;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131624244;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Subtitle = 2131624245;
    
    public static final int TextAppearance_Widget_AppCompat_Toolbar_Title = 2131624246;
    
    public static final int ThemeOverlay_AppCompat = 2131624295;
    
    public static final int ThemeOverlay_AppCompat_ActionBar = 2131624296;
    
    public static final int ThemeOverlay_AppCompat_Dark = 2131624297;
    
    public static final int ThemeOverlay_AppCompat_Dark_ActionBar = 2131624298;
    
    public static final int ThemeOverlay_AppCompat_Dialog = 2131624299;
    
    public static final int ThemeOverlay_AppCompat_Dialog_Alert = 2131624300;
    
    public static final int ThemeOverlay_AppCompat_Light = 2131624301;
    
    public static final int Theme_AppCompat = 2131624247;
    
    public static final int Theme_AppCompat_CompactMenu = 2131624248;
    
    public static final int Theme_AppCompat_DayNight = 2131624249;
    
    public static final int Theme_AppCompat_DayNight_DarkActionBar = 2131624250;
    
    public static final int Theme_AppCompat_DayNight_Dialog = 2131624251;
    
    public static final int Theme_AppCompat_DayNight_DialogWhenLarge = 2131624254;
    
    public static final int Theme_AppCompat_DayNight_Dialog_Alert = 2131624252;
    
    public static final int Theme_AppCompat_DayNight_Dialog_MinWidth = 2131624253;
    
    public static final int Theme_AppCompat_DayNight_NoActionBar = 2131624255;
    
    public static final int Theme_AppCompat_Dialog = 2131624256;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131624259;
    
    public static final int Theme_AppCompat_Dialog_Alert = 2131624257;
    
    public static final int Theme_AppCompat_Dialog_MinWidth = 2131624258;
    
    public static final int Theme_AppCompat_Light = 2131624260;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131624261;
    
    public static final int Theme_AppCompat_Light_Dialog = 2131624262;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131624265;
    
    public static final int Theme_AppCompat_Light_Dialog_Alert = 2131624263;
    
    public static final int Theme_AppCompat_Light_Dialog_MinWidth = 2131624264;
    
    public static final int Theme_AppCompat_Light_NoActionBar = 2131624266;
    
    public static final int Theme_AppCompat_NoActionBar = 2131624267;
    
    public static final int Widget_AppCompat_ActionBar = 2131624314;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131624315;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131624316;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131624317;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131624318;
    
    public static final int Widget_AppCompat_ActionButton = 2131624319;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131624320;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131624321;
    
    public static final int Widget_AppCompat_ActionMode = 2131624322;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131624323;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131624324;
    
    public static final int Widget_AppCompat_Button = 2131624325;
    
    public static final int Widget_AppCompat_ButtonBar = 2131624331;
    
    public static final int Widget_AppCompat_ButtonBar_AlertDialog = 2131624332;
    
    public static final int Widget_AppCompat_Button_Borderless = 2131624326;
    
    public static final int Widget_AppCompat_Button_Borderless_Colored = 2131624327;
    
    public static final int Widget_AppCompat_Button_ButtonBar_AlertDialog = 2131624328;
    
    public static final int Widget_AppCompat_Button_Colored = 2131624329;
    
    public static final int Widget_AppCompat_Button_Small = 2131624330;
    
    public static final int Widget_AppCompat_CompoundButton_CheckBox = 2131624333;
    
    public static final int Widget_AppCompat_CompoundButton_RadioButton = 2131624334;
    
    public static final int Widget_AppCompat_CompoundButton_Switch = 2131624335;
    
    public static final int Widget_AppCompat_DrawerArrowToggle = 2131624336;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131624337;
    
    public static final int Widget_AppCompat_EditText = 2131624338;
    
    public static final int Widget_AppCompat_ImageButton = 2131624339;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131624340;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131624341;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131624342;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131624343;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131624344;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131624345;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131624346;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131624347;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131624348;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131624349;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131624350;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131624351;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131624352;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131624353;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131624354;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131624355;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131624356;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131624357;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131624358;
    
    public static final int Widget_AppCompat_Light_PopupMenu_Overflow = 2131624359;
    
    public static final int Widget_AppCompat_Light_SearchView = 2131624360;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131624361;
    
    public static final int Widget_AppCompat_ListMenuView = 2131624362;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131624363;
    
    public static final int Widget_AppCompat_ListView = 2131624364;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131624365;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131624366;
    
    public static final int Widget_AppCompat_PopupMenu = 2131624367;
    
    public static final int Widget_AppCompat_PopupMenu_Overflow = 2131624368;
    
    public static final int Widget_AppCompat_PopupWindow = 2131624369;
    
    public static final int Widget_AppCompat_ProgressBar = 2131624370;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131624371;
    
    public static final int Widget_AppCompat_RatingBar = 2131624372;
    
    public static final int Widget_AppCompat_RatingBar_Indicator = 2131624373;
    
    public static final int Widget_AppCompat_RatingBar_Small = 2131624374;
    
    public static final int Widget_AppCompat_SearchView = 2131624375;
    
    public static final int Widget_AppCompat_SearchView_ActionBar = 2131624376;
    
    public static final int Widget_AppCompat_SeekBar = 2131624377;
    
    public static final int Widget_AppCompat_SeekBar_Discrete = 2131624378;
    
    public static final int Widget_AppCompat_Spinner = 2131624379;
    
    public static final int Widget_AppCompat_Spinner_DropDown = 2131624380;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131624381;
    
    public static final int Widget_AppCompat_Spinner_Underlined = 2131624382;
    
    public static final int Widget_AppCompat_TextView_SpinnerItem = 2131624383;
    
    public static final int Widget_AppCompat_Toolbar = 2131624384;
    
    public static final int Widget_AppCompat_Toolbar_Button_Navigation = 2131624385;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131624386;
    
    public static final int Widget_Compat_NotificationActionText = 2131624387;
    
    public static final int Widget_Support_CoordinatorLayout = 2131624434;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130903089, 2130903090, 2130903091, 2130903191, 2130903192, 2130903193, 2130903194, 2130903195, 2130903196, 2130903210, 
        2130903215, 2130903216, 2130903227, 2130903270, 2130903275, 2130903280, 2130903281, 2130903283, 2130903293, 2130903303, 
        2130903388, 2130903400, 2130903417, 2130903421, 2130903422, 2130903468, 2130903471, 2130903540, 2130903550 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int ActionBar_background = 0;
    
    public static final int ActionBar_backgroundSplit = 1;
    
    public static final int ActionBar_backgroundStacked = 2;
    
    public static final int ActionBar_contentInsetEnd = 3;
    
    public static final int ActionBar_contentInsetEndWithActions = 4;
    
    public static final int ActionBar_contentInsetLeft = 5;
    
    public static final int ActionBar_contentInsetRight = 6;
    
    public static final int ActionBar_contentInsetStart = 7;
    
    public static final int ActionBar_contentInsetStartWithNavigation = 8;
    
    public static final int ActionBar_customNavigationLayout = 9;
    
    public static final int ActionBar_displayOptions = 10;
    
    public static final int ActionBar_divider = 11;
    
    public static final int ActionBar_elevation = 12;
    
    public static final int ActionBar_height = 13;
    
    public static final int ActionBar_hideOnContentScroll = 14;
    
    public static final int ActionBar_homeAsUpIndicator = 15;
    
    public static final int ActionBar_homeLayout = 16;
    
    public static final int ActionBar_icon = 17;
    
    public static final int ActionBar_indeterminateProgressStyle = 18;
    
    public static final int ActionBar_itemPadding = 19;
    
    public static final int ActionBar_logo = 20;
    
    public static final int ActionBar_navigationMode = 21;
    
    public static final int ActionBar_popupTheme = 22;
    
    public static final int ActionBar_progressBarPadding = 23;
    
    public static final int ActionBar_progressBarStyle = 24;
    
    public static final int ActionBar_subtitle = 25;
    
    public static final int ActionBar_subtitleTextStyle = 26;
    
    public static final int ActionBar_title = 27;
    
    public static final int ActionBar_titleTextStyle = 28;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130903089, 2130903090, 2130903169, 2130903270, 2130903471, 2130903550 };
    
    public static final int ActionMode_background = 0;
    
    public static final int ActionMode_backgroundSplit = 1;
    
    public static final int ActionMode_closeItemLayout = 2;
    
    public static final int ActionMode_height = 3;
    
    public static final int ActionMode_subtitleTextStyle = 4;
    
    public static final int ActionMode_titleTextStyle = 5;
    
    public static final int[] ActivityChooserView = new int[] { 2130903233, 2130903294 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 0;
    
    public static final int ActivityChooserView_initialActivityCount = 1;
    
    public static final int[] AlertDialog = new int[] { 16842994, 2130903124, 2130903125, 2130903379, 2130903380, 2130903397, 2130903444, 2130903445 };
    
    public static final int AlertDialog_android_layout = 0;
    
    public static final int AlertDialog_buttonIconDimen = 1;
    
    public static final int AlertDialog_buttonPanelSideLayout = 2;
    
    public static final int AlertDialog_listItemLayout = 3;
    
    public static final int AlertDialog_listLayout = 4;
    
    public static final int AlertDialog_multiChoiceItemLayout = 5;
    
    public static final int AlertDialog_showTitle = 6;
    
    public static final int AlertDialog_singleChoiceItemLayout = 7;
    
    public static final int[] AnimatedStateListDrawableCompat = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int AnimatedStateListDrawableCompat_android_constantSize = 3;
    
    public static final int AnimatedStateListDrawableCompat_android_dither = 0;
    
    public static final int AnimatedStateListDrawableCompat_android_enterFadeDuration = 4;
    
    public static final int AnimatedStateListDrawableCompat_android_exitFadeDuration = 5;
    
    public static final int AnimatedStateListDrawableCompat_android_variablePadding = 2;
    
    public static final int AnimatedStateListDrawableCompat_android_visible = 1;
    
    public static final int[] AnimatedStateListDrawableItem = new int[] { 16842960, 16843161 };
    
    public static final int AnimatedStateListDrawableItem_android_drawable = 1;
    
    public static final int AnimatedStateListDrawableItem_android_id = 0;
    
    public static final int[] AnimatedStateListDrawableTransition = new int[] { 16843161, 16843849, 16843850, 16843851 };
    
    public static final int AnimatedStateListDrawableTransition_android_drawable = 0;
    
    public static final int AnimatedStateListDrawableTransition_android_fromId = 2;
    
    public static final int AnimatedStateListDrawableTransition_android_reversible = 3;
    
    public static final int AnimatedStateListDrawableTransition_android_toId = 1;
    
    public static final int[] AppCompatImageView = new int[] { 16843033, 2130903455, 2130903538, 2130903539 };
    
    public static final int AppCompatImageView_android_src = 0;
    
    public static final int AppCompatImageView_srcCompat = 1;
    
    public static final int AppCompatImageView_tint = 2;
    
    public static final int AppCompatImageView_tintMode = 3;
    
    public static final int[] AppCompatSeekBar = new int[] { 16843074, 2130903535, 2130903536, 2130903537 };
    
    public static final int AppCompatSeekBar_android_thumb = 0;
    
    public static final int AppCompatSeekBar_tickMark = 1;
    
    public static final int AppCompatSeekBar_tickMarkTint = 2;
    
    public static final int AppCompatSeekBar_tickMarkTintMode = 3;
    
    public static final int[] AppCompatTextHelper = new int[] { 16842804, 16843117, 16843118, 16843119, 16843120, 16843666, 16843667 };
    
    public static final int AppCompatTextHelper_android_drawableBottom = 2;
    
    public static final int AppCompatTextHelper_android_drawableEnd = 6;
    
    public static final int AppCompatTextHelper_android_drawableLeft = 3;
    
    public static final int AppCompatTextHelper_android_drawableRight = 4;
    
    public static final int AppCompatTextHelper_android_drawableStart = 5;
    
    public static final int AppCompatTextHelper_android_drawableTop = 1;
    
    public static final int AppCompatTextHelper_android_textAppearance = 0;
    
    public static final int[] AppCompatTextView = new int[] { 
        16842804, 2130903084, 2130903085, 2130903086, 2130903087, 2130903088, 2130903253, 2130903256, 2130903311, 2130903375, 
        2130903503 };
    
    public static final int AppCompatTextView_android_textAppearance = 0;
    
    public static final int AppCompatTextView_autoSizeMaxTextSize = 1;
    
    public static final int AppCompatTextView_autoSizeMinTextSize = 2;
    
    public static final int AppCompatTextView_autoSizePresetSizes = 3;
    
    public static final int AppCompatTextView_autoSizeStepGranularity = 4;
    
    public static final int AppCompatTextView_autoSizeTextType = 5;
    
    public static final int AppCompatTextView_firstBaselineToTopHeight = 6;
    
    public static final int AppCompatTextView_fontFamily = 7;
    
    public static final int AppCompatTextView_lastBaselineToBottomHeight = 8;
    
    public static final int AppCompatTextView_lineHeight = 9;
    
    public static final int AppCompatTextView_textAllCaps = 10;
    
    public static final int[] AppCompatTheme = new int[] { 
        16842839, 16842926, 2130903040, 2130903041, 2130903042, 2130903043, 2130903044, 2130903045, 2130903046, 2130903047, 
        2130903048, 2130903049, 2130903050, 2130903051, 2130903052, 2130903054, 2130903055, 2130903056, 2130903057, 2130903058, 
        2130903059, 2130903060, 2130903061, 2130903062, 2130903063, 2130903064, 2130903065, 2130903066, 2130903067, 2130903068, 
        2130903069, 2130903070, 2130903073, 2130903074, 2130903075, 2130903076, 2130903077, 2130903083, 2130903104, 2130903118, 
        2130903119, 2130903120, 2130903121, 2130903122, 2130903126, 2130903127, 2130903138, 2130903143, 2130903175, 2130903176, 
        2130903177, 2130903178, 2130903179, 2130903180, 2130903181, 2130903182, 2130903183, 2130903185, 2130903203, 2130903212, 
        2130903213, 2130903214, 2130903217, 2130903219, 2130903222, 2130903223, 2130903224, 2130903225, 2130903226, 2130903280, 
        2130903292, 2130903377, 2130903378, 2130903381, 2130903382, 2130903383, 2130903384, 2130903385, 2130903386, 2130903387, 
        2130903408, 2130903409, 2130903410, 2130903416, 2130903418, 2130903425, 2130903426, 2130903427, 2130903428, 2130903436, 
        2130903437, 2130903438, 2130903439, 2130903452, 2130903453, 2130903475, 2130903514, 2130903515, 2130903516, 2130903517, 
        2130903519, 2130903520, 2130903521, 2130903522, 2130903525, 2130903526, 2130903552, 2130903553, 2130903554, 2130903555, 
        2130903562, 2130903564, 2130903565, 2130903566, 2130903567, 2130903568, 2130903569, 2130903570, 2130903571, 2130903572, 
        2130903573 };
    
    public static final int AppCompatTheme_actionBarDivider = 2;
    
    public static final int AppCompatTheme_actionBarItemBackground = 3;
    
    public static final int AppCompatTheme_actionBarPopupTheme = 4;
    
    public static final int AppCompatTheme_actionBarSize = 5;
    
    public static final int AppCompatTheme_actionBarSplitStyle = 6;
    
    public static final int AppCompatTheme_actionBarStyle = 7;
    
    public static final int AppCompatTheme_actionBarTabBarStyle = 8;
    
    public static final int AppCompatTheme_actionBarTabStyle = 9;
    
    public static final int AppCompatTheme_actionBarTabTextStyle = 10;
    
    public static final int AppCompatTheme_actionBarTheme = 11;
    
    public static final int AppCompatTheme_actionBarWidgetTheme = 12;
    
    public static final int AppCompatTheme_actionButtonStyle = 13;
    
    public static final int AppCompatTheme_actionDropDownStyle = 14;
    
    public static final int AppCompatTheme_actionMenuTextAppearance = 15;
    
    public static final int AppCompatTheme_actionMenuTextColor = 16;
    
    public static final int AppCompatTheme_actionModeBackground = 17;
    
    public static final int AppCompatTheme_actionModeCloseButtonStyle = 18;
    
    public static final int AppCompatTheme_actionModeCloseDrawable = 19;
    
    public static final int AppCompatTheme_actionModeCopyDrawable = 20;
    
    public static final int AppCompatTheme_actionModeCutDrawable = 21;
    
    public static final int AppCompatTheme_actionModeFindDrawable = 22;
    
    public static final int AppCompatTheme_actionModePasteDrawable = 23;
    
    public static final int AppCompatTheme_actionModePopupWindowStyle = 24;
    
    public static final int AppCompatTheme_actionModeSelectAllDrawable = 25;
    
    public static final int AppCompatTheme_actionModeShareDrawable = 26;
    
    public static final int AppCompatTheme_actionModeSplitBackground = 27;
    
    public static final int AppCompatTheme_actionModeStyle = 28;
    
    public static final int AppCompatTheme_actionModeWebSearchDrawable = 29;
    
    public static final int AppCompatTheme_actionOverflowButtonStyle = 30;
    
    public static final int AppCompatTheme_actionOverflowMenuStyle = 31;
    
    public static final int AppCompatTheme_activityChooserViewStyle = 32;
    
    public static final int AppCompatTheme_alertDialogButtonGroupStyle = 33;
    
    public static final int AppCompatTheme_alertDialogCenterButtons = 34;
    
    public static final int AppCompatTheme_alertDialogStyle = 35;
    
    public static final int AppCompatTheme_alertDialogTheme = 36;
    
    public static final int AppCompatTheme_android_windowAnimationStyle = 1;
    
    public static final int AppCompatTheme_android_windowIsFloating = 0;
    
    public static final int AppCompatTheme_autoCompleteTextViewStyle = 37;
    
    public static final int AppCompatTheme_borderlessButtonStyle = 38;
    
    public static final int AppCompatTheme_buttonBarButtonStyle = 39;
    
    public static final int AppCompatTheme_buttonBarNegativeButtonStyle = 40;
    
    public static final int AppCompatTheme_buttonBarNeutralButtonStyle = 41;
    
    public static final int AppCompatTheme_buttonBarPositiveButtonStyle = 42;
    
    public static final int AppCompatTheme_buttonBarStyle = 43;
    
    public static final int AppCompatTheme_buttonStyle = 44;
    
    public static final int AppCompatTheme_buttonStyleSmall = 45;
    
    public static final int AppCompatTheme_checkboxStyle = 46;
    
    public static final int AppCompatTheme_checkedTextViewStyle = 47;
    
    public static final int AppCompatTheme_colorAccent = 48;
    
    public static final int AppCompatTheme_colorBackgroundFloating = 49;
    
    public static final int AppCompatTheme_colorButtonNormal = 50;
    
    public static final int AppCompatTheme_colorControlActivated = 51;
    
    public static final int AppCompatTheme_colorControlHighlight = 52;
    
    public static final int AppCompatTheme_colorControlNormal = 53;
    
    public static final int AppCompatTheme_colorError = 54;
    
    public static final int AppCompatTheme_colorPrimary = 55;
    
    public static final int AppCompatTheme_colorPrimaryDark = 56;
    
    public static final int AppCompatTheme_colorSwitchThumbNormal = 57;
    
    public static final int AppCompatTheme_controlBackground = 58;
    
    public static final int AppCompatTheme_dialogCornerRadius = 59;
    
    public static final int AppCompatTheme_dialogPreferredPadding = 60;
    
    public static final int AppCompatTheme_dialogTheme = 61;
    
    public static final int AppCompatTheme_dividerHorizontal = 62;
    
    public static final int AppCompatTheme_dividerVertical = 63;
    
    public static final int AppCompatTheme_dropDownListViewStyle = 64;
    
    public static final int AppCompatTheme_dropdownListPreferredItemHeight = 65;
    
    public static final int AppCompatTheme_editTextBackground = 66;
    
    public static final int AppCompatTheme_editTextColor = 67;
    
    public static final int AppCompatTheme_editTextStyle = 68;
    
    public static final int AppCompatTheme_homeAsUpIndicator = 69;
    
    public static final int AppCompatTheme_imageButtonStyle = 70;
    
    public static final int AppCompatTheme_listChoiceBackgroundIndicator = 71;
    
    public static final int AppCompatTheme_listDividerAlertDialog = 72;
    
    public static final int AppCompatTheme_listMenuViewStyle = 73;
    
    public static final int AppCompatTheme_listPopupWindowStyle = 74;
    
    public static final int AppCompatTheme_listPreferredItemHeight = 75;
    
    public static final int AppCompatTheme_listPreferredItemHeightLarge = 76;
    
    public static final int AppCompatTheme_listPreferredItemHeightSmall = 77;
    
    public static final int AppCompatTheme_listPreferredItemPaddingLeft = 78;
    
    public static final int AppCompatTheme_listPreferredItemPaddingRight = 79;
    
    public static final int AppCompatTheme_panelBackground = 80;
    
    public static final int AppCompatTheme_panelMenuListTheme = 81;
    
    public static final int AppCompatTheme_panelMenuListWidth = 82;
    
    public static final int AppCompatTheme_popupMenuStyle = 83;
    
    public static final int AppCompatTheme_popupWindowStyle = 84;
    
    public static final int AppCompatTheme_radioButtonStyle = 85;
    
    public static final int AppCompatTheme_ratingBarStyle = 86;
    
    public static final int AppCompatTheme_ratingBarStyleIndicator = 87;
    
    public static final int AppCompatTheme_ratingBarStyleSmall = 88;
    
    public static final int AppCompatTheme_searchViewStyle = 89;
    
    public static final int AppCompatTheme_seekBarStyle = 90;
    
    public static final int AppCompatTheme_selectableItemBackground = 91;
    
    public static final int AppCompatTheme_selectableItemBackgroundBorderless = 92;
    
    public static final int AppCompatTheme_spinnerDropDownItemStyle = 93;
    
    public static final int AppCompatTheme_spinnerStyle = 94;
    
    public static final int AppCompatTheme_switchStyle = 95;
    
    public static final int AppCompatTheme_textAppearanceLargePopupMenu = 96;
    
    public static final int AppCompatTheme_textAppearanceListItem = 97;
    
    public static final int AppCompatTheme_textAppearanceListItemSecondary = 98;
    
    public static final int AppCompatTheme_textAppearanceListItemSmall = 99;
    
    public static final int AppCompatTheme_textAppearancePopupMenuHeader = 100;
    
    public static final int AppCompatTheme_textAppearanceSearchResultSubtitle = 101;
    
    public static final int AppCompatTheme_textAppearanceSearchResultTitle = 102;
    
    public static final int AppCompatTheme_textAppearanceSmallPopupMenu = 103;
    
    public static final int AppCompatTheme_textColorAlertDialogListItem = 104;
    
    public static final int AppCompatTheme_textColorSearchUrl = 105;
    
    public static final int AppCompatTheme_toolbarNavigationButtonStyle = 106;
    
    public static final int AppCompatTheme_toolbarStyle = 107;
    
    public static final int AppCompatTheme_tooltipForegroundColor = 108;
    
    public static final int AppCompatTheme_tooltipFrameBackground = 109;
    
    public static final int AppCompatTheme_viewInflaterClass = 110;
    
    public static final int AppCompatTheme_windowActionBar = 111;
    
    public static final int AppCompatTheme_windowActionBarOverlay = 112;
    
    public static final int AppCompatTheme_windowActionModeOverlay = 113;
    
    public static final int AppCompatTheme_windowFixedHeightMajor = 114;
    
    public static final int AppCompatTheme_windowFixedHeightMinor = 115;
    
    public static final int AppCompatTheme_windowFixedWidthMajor = 116;
    
    public static final int AppCompatTheme_windowFixedWidthMinor = 117;
    
    public static final int AppCompatTheme_windowMinWidthMajor = 118;
    
    public static final int AppCompatTheme_windowMinWidthMinor = 119;
    
    public static final int AppCompatTheme_windowNoTitle = 120;
    
    public static final int[] ButtonBarLayout = new int[] { 2130903078 };
    
    public static final int ButtonBarLayout_allowStacking = 0;
    
    public static final int[] ColorStateListItem = new int[] { 16843173, 16843551, 2130903079 };
    
    public static final int ColorStateListItem_alpha = 2;
    
    public static final int ColorStateListItem_android_alpha = 1;
    
    public static final int ColorStateListItem_android_color = 0;
    
    public static final int[] CompoundButton = new int[] { 16843015, 2130903128, 2130903129 };
    
    public static final int CompoundButton_android_button = 0;
    
    public static final int CompoundButton_buttonTint = 1;
    
    public static final int CompoundButton_buttonTintMode = 2;
    
    public static final int[] CoordinatorLayout = new int[] { 2130903309, 2130903462 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130903314, 2130903315, 2130903316, 2130903360, 2130903369, 2130903370 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] DrawerArrowToggle = new int[] { 2130903081, 2130903082, 2130903094, 2130903174, 2130903220, 2130903267, 2130903451, 2130903531 };
    
    public static final int DrawerArrowToggle_arrowHeadLength = 0;
    
    public static final int DrawerArrowToggle_arrowShaftLength = 1;
    
    public static final int DrawerArrowToggle_barLength = 2;
    
    public static final int DrawerArrowToggle_color = 3;
    
    public static final int DrawerArrowToggle_drawableSize = 4;
    
    public static final int DrawerArrowToggle_gapBetweenBars = 5;
    
    public static final int DrawerArrowToggle_spinBars = 6;
    
    public static final int DrawerArrowToggle_thickness = 7;
    
    public static final int[] FontFamily = new int[] { 2130903257, 2130903258, 2130903259, 2130903260, 2130903261, 2130903262 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 16844143, 16844144, 2130903255, 2130903263, 2130903264, 2130903265, 2130903560 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontVariationSettings = 4;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_android_ttcIndex = 3;
    
    public static final int FontFamilyFont_font = 5;
    
    public static final int FontFamilyFont_fontStyle = 6;
    
    public static final int FontFamilyFont_fontVariationSettings = 7;
    
    public static final int FontFamilyFont_fontWeight = 8;
    
    public static final int FontFamilyFont_ttcIndex = 9;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
    
    public static final int[] GradientColor = new int[] { 
        16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 
        16844050, 16844051 };
    
    public static final int[] GradientColorItem = new int[] { 16843173, 16844052 };
    
    public static final int GradientColorItem_android_color = 0;
    
    public static final int GradientColorItem_android_offset = 1;
    
    public static final int GradientColor_android_centerColor = 7;
    
    public static final int GradientColor_android_centerX = 3;
    
    public static final int GradientColor_android_centerY = 4;
    
    public static final int GradientColor_android_endColor = 1;
    
    public static final int GradientColor_android_endX = 10;
    
    public static final int GradientColor_android_endY = 11;
    
    public static final int GradientColor_android_gradientRadius = 5;
    
    public static final int GradientColor_android_startColor = 0;
    
    public static final int GradientColor_android_startX = 8;
    
    public static final int GradientColor_android_startY = 9;
    
    public static final int GradientColor_android_tileMode = 6;
    
    public static final int GradientColor_android_type = 2;
    
    public static final int[] LinearLayoutCompat = new int[] { 16842927, 16842948, 16843046, 16843047, 16843048, 2130903216, 2130903218, 2130903395, 2130903441 };
    
    public static final int[] LinearLayoutCompat_Layout = new int[] { 16842931, 16842996, 16842997, 16843137 };
    
    public static final int LinearLayoutCompat_Layout_android_layout_gravity = 0;
    
    public static final int LinearLayoutCompat_Layout_android_layout_height = 2;
    
    public static final int LinearLayoutCompat_Layout_android_layout_weight = 3;
    
    public static final int LinearLayoutCompat_Layout_android_layout_width = 1;
    
    public static final int LinearLayoutCompat_android_baselineAligned = 2;
    
    public static final int LinearLayoutCompat_android_baselineAlignedChildIndex = 3;
    
    public static final int LinearLayoutCompat_android_gravity = 0;
    
    public static final int LinearLayoutCompat_android_orientation = 1;
    
    public static final int LinearLayoutCompat_android_weightSum = 4;
    
    public static final int LinearLayoutCompat_divider = 5;
    
    public static final int LinearLayoutCompat_dividerPadding = 6;
    
    public static final int LinearLayoutCompat_measureWithLargestChild = 7;
    
    public static final int LinearLayoutCompat_showDividers = 8;
    
    public static final int[] ListPopupWindow = new int[] { 16843436, 16843437 };
    
    public static final int ListPopupWindow_android_dropDownHorizontalOffset = 0;
    
    public static final int ListPopupWindow_android_dropDownVerticalOffset = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130903053, 2130903071, 2130903072, 2130903080, 2130903190, 2130903289, 2130903290, 
        2130903402, 2130903440, 2130903556 };
    
    public static final int MenuItem_actionLayout = 13;
    
    public static final int MenuItem_actionProviderClass = 14;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_alphabeticModifiers = 16;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_contentDescription = 17;
    
    public static final int MenuItem_iconTint = 18;
    
    public static final int MenuItem_iconTintMode = 19;
    
    public static final int MenuItem_numericModifiers = 20;
    
    public static final int MenuItem_showAsAction = 21;
    
    public static final int MenuItem_tooltipText = 22;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 2130903419, 2130903466 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int MenuView_preserveIconSpacing = 7;
    
    public static final int MenuView_subMenuArrow = 8;
    
    public static final int[] PopupWindow = new int[] { 16843126, 16843465, 2130903403 };
    
    public static final int[] PopupWindowBackgroundState = new int[] { 2130903457 };
    
    public static final int PopupWindowBackgroundState_state_above_anchor = 0;
    
    public static final int PopupWindow_android_popupAnimationStyle = 1;
    
    public static final int PopupWindow_android_popupBackground = 0;
    
    public static final int PopupWindow_overlapAnchor = 2;
    
    public static final int[] RecycleListView = new int[] { 2130903404, 2130903407 };
    
    public static final int RecycleListView_paddingBottomNoButtons = 0;
    
    public static final int RecycleListView_paddingTopNoTitle = 1;
    
    public static final int[] SearchView = new int[] { 
        16842970, 16843039, 16843296, 16843364, 2130903162, 2130903186, 2130903211, 2130903268, 2130903291, 2130903312, 
        2130903423, 2130903424, 2130903434, 2130903435, 2130903467, 2130903472, 2130903563 };
    
    public static final int SearchView_android_focusable = 0;
    
    public static final int SearchView_android_imeOptions = 3;
    
    public static final int SearchView_android_inputType = 2;
    
    public static final int SearchView_android_maxWidth = 1;
    
    public static final int SearchView_closeIcon = 4;
    
    public static final int SearchView_commitIcon = 5;
    
    public static final int SearchView_defaultQueryHint = 6;
    
    public static final int SearchView_goIcon = 7;
    
    public static final int SearchView_iconifiedByDefault = 8;
    
    public static final int SearchView_layout = 9;
    
    public static final int SearchView_queryBackground = 10;
    
    public static final int SearchView_queryHint = 11;
    
    public static final int SearchView_searchHintIcon = 12;
    
    public static final int SearchView_searchIcon = 13;
    
    public static final int SearchView_submitBackground = 14;
    
    public static final int SearchView_suggestionRowLayout = 15;
    
    public static final int SearchView_voiceIcon = 16;
    
    public static final int[] Spinner = new int[] { 16842930, 16843126, 16843131, 16843362, 2130903417 };
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_entries = 0;
    
    public static final int Spinner_android_popupBackground = 1;
    
    public static final int Spinner_android_prompt = 2;
    
    public static final int Spinner_popupTheme = 4;
    
    public static final int[] StateListDrawable = new int[] { 16843036, 16843156, 16843157, 16843158, 16843532, 16843533 };
    
    public static final int[] StateListDrawableItem = new int[] { 16843161 };
    
    public static final int StateListDrawableItem_android_drawable = 0;
    
    public static final int StateListDrawable_android_constantSize = 3;
    
    public static final int StateListDrawable_android_dither = 0;
    
    public static final int StateListDrawable_android_enterFadeDuration = 4;
    
    public static final int StateListDrawable_android_exitFadeDuration = 5;
    
    public static final int StateListDrawable_android_variablePadding = 2;
    
    public static final int StateListDrawable_android_visible = 1;
    
    public static final int[] SwitchCompat = new int[] { 
        16843044, 16843045, 16843074, 2130903443, 2130903454, 2130903473, 2130903474, 2130903476, 2130903532, 2130903533, 
        2130903534, 2130903557, 2130903558, 2130903559 };
    
    public static final int SwitchCompat_android_textOff = 1;
    
    public static final int SwitchCompat_android_textOn = 0;
    
    public static final int SwitchCompat_android_thumb = 2;
    
    public static final int SwitchCompat_showText = 3;
    
    public static final int SwitchCompat_splitTrack = 4;
    
    public static final int SwitchCompat_switchMinWidth = 5;
    
    public static final int SwitchCompat_switchPadding = 6;
    
    public static final int SwitchCompat_switchTextAppearance = 7;
    
    public static final int SwitchCompat_thumbTextPadding = 8;
    
    public static final int SwitchCompat_thumbTint = 9;
    
    public static final int SwitchCompat_thumbTintMode = 10;
    
    public static final int SwitchCompat_track = 11;
    
    public static final int SwitchCompat_trackTint = 12;
    
    public static final int SwitchCompat_trackTintMode = 13;
    
    public static final int[] TextAppearance = new int[] { 
        16842901, 16842902, 16842903, 16842904, 16842906, 16842907, 16843105, 16843106, 16843107, 16843108, 
        16843692, 2130903256, 2130903503 };
    
    public static final int TextAppearance_android_fontFamily = 10;
    
    public static final int TextAppearance_android_shadowColor = 6;
    
    public static final int TextAppearance_android_shadowDx = 7;
    
    public static final int TextAppearance_android_shadowDy = 8;
    
    public static final int TextAppearance_android_shadowRadius = 9;
    
    public static final int TextAppearance_android_textColor = 3;
    
    public static final int TextAppearance_android_textColorHint = 4;
    
    public static final int TextAppearance_android_textColorLink = 5;
    
    public static final int TextAppearance_android_textSize = 0;
    
    public static final int TextAppearance_android_textStyle = 2;
    
    public static final int TextAppearance_android_typeface = 1;
    
    public static final int TextAppearance_fontFamily = 11;
    
    public static final int TextAppearance_textAllCaps = 12;
    
    public static final int[] Toolbar = new int[] { 
        16842927, 16843072, 2130903123, 2130903170, 2130903171, 2130903191, 2130903192, 2130903193, 2130903194, 2130903195, 
        2130903196, 2130903388, 2130903389, 2130903393, 2130903398, 2130903399, 2130903417, 2130903468, 2130903469, 2130903470, 
        2130903540, 2130903542, 2130903543, 2130903544, 2130903545, 2130903546, 2130903547, 2130903548, 2130903549 };
    
    public static final int Toolbar_android_gravity = 0;
    
    public static final int Toolbar_android_minHeight = 1;
    
    public static final int Toolbar_buttonGravity = 2;
    
    public static final int Toolbar_collapseContentDescription = 3;
    
    public static final int Toolbar_collapseIcon = 4;
    
    public static final int Toolbar_contentInsetEnd = 5;
    
    public static final int Toolbar_contentInsetEndWithActions = 6;
    
    public static final int Toolbar_contentInsetLeft = 7;
    
    public static final int Toolbar_contentInsetRight = 8;
    
    public static final int Toolbar_contentInsetStart = 9;
    
    public static final int Toolbar_contentInsetStartWithNavigation = 10;
    
    public static final int Toolbar_logo = 11;
    
    public static final int Toolbar_logoDescription = 12;
    
    public static final int Toolbar_maxButtonHeight = 13;
    
    public static final int Toolbar_navigationContentDescription = 14;
    
    public static final int Toolbar_navigationIcon = 15;
    
    public static final int Toolbar_popupTheme = 16;
    
    public static final int Toolbar_subtitle = 17;
    
    public static final int Toolbar_subtitleTextAppearance = 18;
    
    public static final int Toolbar_subtitleTextColor = 19;
    
    public static final int Toolbar_title = 20;
    
    public static final int Toolbar_titleMargin = 21;
    
    public static final int Toolbar_titleMarginBottom = 22;
    
    public static final int Toolbar_titleMarginEnd = 23;
    
    public static final int Toolbar_titleMarginStart = 24;
    
    public static final int Toolbar_titleMarginTop = 25;
    
    public static final int Toolbar_titleMargins = 26;
    
    public static final int Toolbar_titleTextAppearance = 27;
    
    public static final int Toolbar_titleTextColor = 28;
    
    public static final int[] View = new int[] { 16842752, 16842970, 2130903405, 2130903406, 2130903530 };
    
    public static final int[] ViewBackgroundHelper = new int[] { 16842964, 2130903092, 2130903093 };
    
    public static final int ViewBackgroundHelper_android_background = 0;
    
    public static final int ViewBackgroundHelper_backgroundTint = 1;
    
    public static final int ViewBackgroundHelper_backgroundTintMode = 2;
    
    public static final int[] ViewStubCompat = new int[] { 16842960, 16842994, 16842995 };
    
    public static final int ViewStubCompat_android_id = 0;
    
    public static final int ViewStubCompat_android_inflatedId = 2;
    
    public static final int ViewStubCompat_android_layout = 1;
    
    public static final int View_android_focusable = 1;
    
    public static final int View_android_theme = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 3;
    
    public static final int View_theme = 4;
  }
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes2-dex2jar.jar!/android/support/v7/appcompat/R.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */