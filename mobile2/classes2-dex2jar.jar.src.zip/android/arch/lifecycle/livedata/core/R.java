package android.arch.lifecycle.livedata.core;

public final class R {}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes2-dex2jar.jar!/android/arch/lifecycle/livedata/core/R.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */