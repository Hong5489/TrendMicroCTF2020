package com.trendmicro.keybox;

public final class BuildConfig {
  public static final String APPLICATION_ID = "com.trendmicro.keybox";
  
  public static final String BUILD_TYPE = "debug";
  
  public static final boolean DEBUG = Boolean.parseBoolean("true");
  
  public static final int VERSION_CODE = 1;
  
  public static final String VERSION_NAME = "1.0";
}


/* Location:              /root/Downloads/trendmicro/mobile2/test/classes2-dex2jar.jar!/com/trendmicro/keybox/BuildConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */